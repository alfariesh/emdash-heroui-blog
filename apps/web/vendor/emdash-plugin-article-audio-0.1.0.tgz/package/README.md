# emdash-plugin-article-audio

"Listen to this article" for [EmDash](https://emdashcms.com): turn posts into narrated MP3s with ElevenLabs or Google Cloud Text-to-Speech, with **word timestamps** for read-along highlighting and **[expression tags]** such as `[whispers]` or `[pause]`. One public JSON endpoint serves the audio and timings to your website and your mobile app.

- **Engines:** ElevenLabs (Eleven v4, v3, Multilingual v2, Flash v2.5), Google Cloud (Neural2, WaveNet, Standard, Chirp 3 HD), and a keyless *silent test audio* engine for development. The provider interface is small, so you can add your own.
- **Word timing:** ElevenLabs returns per-character timestamps; Google returns `<mark>` timepoints on Neural2, WaveNet and Standard voices. Other voices get timing estimated from text length (`timing: "estimated"`).
- **Expression tags:** editors add cues in the script without changing the page. Eleven v4/v3 read every `[tag]`; other engines turn `[pause]` / `[pause 1.5s]` into a break and drop the rest.
- **Long articles:** text is split between paragraphs (or sentences), synthesized one chunk per request, and joined into one constant-bitrate MP3. Chunks are stitched on Multilingual v2 and Flash for a seamless voice. A failed chunk is retried from where it stopped, so you never pay for the same text twice.
- **Background work:** the editor panel drives generation while it is open; a per-minute worker finishes jobs nobody is watching, including "generate on publish".
- **Stale detection:** the panel tells editors when the text changed after the audio was made.

Requires EmDash 1.4+. Runs on Cloudflare Workers and Node.js.

## Install

```bash
pnpm add emdash-plugin-article-audio
```

```js
// astro.config.mjs
import { articleAudio } from "emdash-plugin-article-audio";

emdash({
	// ...
	plugins: [articleAudio()],
});
```

Deploy, then open **Plugins → article-audio** in the admin:

| Setting | Default | Notes |
| --- | --- | --- |
| Speech engine | ElevenLabs | Default for new audio. Editors can pick another engine per entry. |
| Collections | `posts` | Comma-separated. Each gets an **Audio** panel in the editor sidebar. |
| Body fields | `content, body` | Portable Text field to narrate (first match wins). |
| Read the title first / Read the excerpt | on / off | |
| Generate on publish | off | Creates or refreshes audio in the background when published text changes. Billed per run. |
| Language, speaking speed | auto, 1 | |
| ElevenLabs API key, default voice, model, quality | | Key needs Text to Speech and Voices (read). |
| Google service account key (JSON) or API key, default voice | | Service-account keys are signed into OAuth tokens with WebCrypto. |

Secrets are stored encrypted with `EMDASH_ENCRYPTION_KEY`.

## Editing a narration

The **Audio** panel (Editor role and up) shows a preview player, the voice and timing, and whether the text changed since the audio was made. **Voice & script** opens a dialog where editors:

- choose the engine, voice (with a preview), model and speed for this entry;
- switch blocks off (code walkthroughs, captions, footnotes);
- rewrite what is read (spell out an acronym, fix a pronunciation) — highlighting still follows the page text, because spoken words are matched back to written words;
- insert expression tags from a palette.

**Generate audio** synthesizes chunk by chunk with a progress bar. Generating again replaces the previous file.

## Rendering on a site

The plugin stores the MP3 in the media library and serves a public route:

```
GET /_emdash/api/plugins/article-audio/narration?collection=posts&id=<entry id>
→ { "success": true, "data": Narration }   (404 when there is none or the entry is not published)
```

```ts
interface Narration {
	format: 1;
	collection: string;
	contentId: string;
	locale: string | null;
	audio: { url: string; mimeType: "audio/mpeg"; durationMs: number; bytes: number };
	voice: { provider: string; providerLabel: string; voiceId: string; voiceName: string | null; model: string | null };
	timing: "word" | "estimated";
	sourceHash: string;
	generatedAt: string;
	blocks: Array<{
		key: string; // Portable Text _key, or "title" / "excerpt"
		kind: "title" | "heading" | "paragraph" | "quote" | "list-item";
		text: string; // as rendered; words are its whitespace-separated tokens
		startMs: number;
		endMs: number;
		words: number[]; // [start0, end0, start1, end1, …] in ms
	}>;
}
```

Server code in an Astro page can call the route in-process:

```ts
const result = await Astro.locals.emdash.handlePublicPluginApiRoute(
	"article-audio", "GET", "narration",
	new Request(new URL(`/_emdash/api/plugins/article-audio/narration?collection=posts&id=${id}`, Astro.url)),
);
```

`emdash-plugin-article-audio/client` exports the types and dependency-free helpers for players on the web and in React Native:

```ts
import { positionAt, wordRanges } from "emdash-plugin-article-audio/client";

const position = positionAt(narration, audio.currentTime * 1000); // { block, word } | null
```

For read-along highlighting on the web, match each block to the rendered element by its text and paint the word with the [CSS Custom Highlight API](https://developer.mozilla.org/docs/Web/API/CSS_Custom_Highlight_API) — no changes to your Portable Text markup. Media URLs support HTTP range requests, so seeking works in every browser.

## Capabilities and hosts

Native plugin (it ships a React admin panel), so it runs with the site's authority. It declares:

| Capability | Used for |
| --- | --- |
| `content:read` | Reading the entry text and checking it is published |
| `media:write` | Uploading chunk and final MP3s, deleting replaced ones |
| `media:bytes:read` | Joining chunk MP3s into one file |
| `network:request` | `api.elevenlabs.io`, `texttospeech.googleapis.com`, `oauth2.googleapis.com` |

Storage collections: `narrations`, `jobs`, `scripts`. A cron task named `worker` runs every minute.

## Limits

- One request is capped at 8 MiB of response, so ElevenLabs chunks are sized to the chosen bitrate (≈2,500 characters at 128 kbps). Google requests are capped at 5,000 bytes of SSML, and Google MP3 is fixed at 32 kbps.
- Each chunk runs in its own request (one provider call and one upload), well within Workers limits. Very long texts (over ~16 MiB of audio) cannot be joined.
- OpenAI's `/v1/audio/speech` models are scheduled to shut down on 2027-01-06 and return no timestamps, so they are not included.

## Adding an engine

Implement `Provider` (`src/providers/types.ts`): `limits`, `synthesize` (return constant-bitrate MP3 bytes plus spoken words per segment, or `null` timing), `listVoices`, and register it in `src/providers/index.ts`. Helpers in `src/core/render.ts` turn per-character timestamps into words; `src/core/tags.ts` parses expression tags.

## Develop

```bash
pnpm install
pnpm test        # node --test, no network
pnpm typecheck
pnpm build       # dist/ for the server entry and ./client
```

## License

MIT
