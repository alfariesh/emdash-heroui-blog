/**
 * Admin UI: the "Audio" panel in the content editor sidebar.
 *
 * Shows the current narration with a preview player, whether the text has
 * changed since it was made, and drives generation one chunk at a time
 * while the panel is open (the cron worker finishes it otherwise). The
 * script dialog picks the engine, voice and model and lets editors adjust
 * what is read: skip a block, reword it, or add [expression tags].
 */
import { Badge, Banner, Button, Dialog, Meter, Select, Switch, Textarea } from "@cloudflare/kumo";
import { apiFetch, parseApiResponse, type ContentEditorPanelContext, type ContentEditorPanelExtension } from "@emdash-cms/admin";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import type { Narration } from "../client/index.ts";

const BASE = "/_emdash/api/plugins/article-audio";

interface JobSummary {
	state: "idle" | "running" | "failed";
	done: number;
	total: number;
	chars: number;
	error: string | null;
	busy: boolean;
	finalizing: boolean;
}

interface Status {
	narration: Narration | null;
	stale: boolean;
	job: JobSummary;
	source: { blocks: number; chars: number; published: boolean };
	voice: {
		provider: string;
		providerLabel: string;
		configured: boolean;
		voiceId: string;
		voiceName: string | null;
		model: string | null;
		timing: "word" | "estimated";
	};
}

interface ScriptBlock {
	key: string;
	kind: string;
	text: string;
	script: string | null;
	skipped: boolean;
}

interface ProviderChoice {
	id: string;
	label: string;
	configured: boolean;
	models: Array<{ id: string; label: string; tags: boolean }>;
}

interface ScriptData {
	blocks: ScriptBlock[];
	voice: { provider: string; voiceId: string; voiceName: string | null; model: string | null; speed: number };
	providers: ProviderChoice[];
	tags: string[];
	chars: number;
}

interface VoiceList {
	configured: boolean;
	voices: Array<{ id: string; name: string; description?: string; previewUrl?: string }>;
}

async function get<T>(route: string, params: Record<string, string>): Promise<T> {
	return parseApiResponse<T>(await apiFetch(`${BASE}/${route}?${new URLSearchParams(params)}`), "Audio request failed");
}

async function post<T>(route: string, body: Record<string, unknown>): Promise<T> {
	return parseApiResponse<T>(
		await apiFetch(`${BASE}/${route}`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(body),
		}),
		"Audio request failed",
	);
}

const errorCode = (error: unknown) => (error && typeof error === "object" && "code" in error ? String(error.code) : null);
const errorMessage = (error: unknown) => (error instanceof Error ? error.message : "Something went wrong");

function formatDuration(ms: number) {
	const total = Math.round(ms / 1000);
	const h = Math.floor(total / 3600);
	const m = Math.floor((total % 3600) / 60);
	const s = String(total % 60).padStart(2, "0");
	return h ? `${h}:${String(m).padStart(2, "0")}:${s}` : `${m}:${s}`;
}

const number = new Intl.NumberFormat("en-US");

function AudioPanel({ collection, entry }: ContentEditorPanelContext) {
	const id = entry.id;
	const queryClient = useQueryClient();
	const statusKey = ["article-audio", "status", collection, id];
	const [scriptOpen, setScriptOpen] = useState(false);

	const status = useQuery({
		queryKey: statusKey,
		queryFn: () => get<Status>("status", { collection, id }),
		retry: (count, error) => count < 2 && errorCode(error) !== "COLLECTION_DISABLED",
	});
	const setStatus = (next: Status) => queryClient.setQueryData(statusKey, next);

	const action = useMutation({
		mutationFn: ({ route, body }: { route: string; body?: Record<string, unknown> }) => post<Status>(route, { collection, id, ...body }),
		onSuccess: setStatus,
	});

	// Drive the job while the panel is open: one chunk per request.
	const job = status.data?.job;
	const driving = useRef(false);
	useEffect(() => {
		if (!job || job.state !== "running" || driving.current) return;
		let cancelled = false;
		driving.current = true;
		const timer = setTimeout(
			async () => {
				try {
					const next = await post<Status>("step", { collection, id });
					if (!cancelled) setStatus(next);
				} catch {
					if (!cancelled) void status.refetch();
				} finally {
					driving.current = false;
				}
			},
			job.busy ? 4000 : 50,
		);
		return () => {
			cancelled = true;
			clearTimeout(timer);
			driving.current = false;
		};
	}, [job?.state, job?.done, job?.busy, job?.finalizing, status.dataUpdatedAt]);

	if (status.isPending) return <p className="text-sm text-kumo-subtle">Loading audio…</p>;
	if (status.isError) {
		if (errorCode(status.error) === "COLLECTION_DISABLED") {
			return <p className="text-sm text-kumo-subtle">Audio is off for this collection. Turn it on in the article-audio plugin settings.</p>;
		}
		return (
			<div className="grid gap-2">
				<p role="alert" className="text-sm text-kumo-danger">{errorMessage(status.error)}</p>
				<Button size="sm" variant="secondary" onClick={() => void status.refetch()}>Retry</Button>
			</div>
		);
	}

	const { narration, stale, source, voice } = status.data;
	const running = status.data.job.state === "running";
	const failed = status.data.job.state === "failed";
	const busy = action.isPending || running;
	const run = (route: string, body?: Record<string, unknown>) => action.mutate({ route, body });

	return (
		<div className="grid gap-3 text-sm">
			{narration ? (
				<div className="grid gap-2">
					<audio controls preload="none" src={narration.audio.url} className="w-full" />
					<p className="text-xs text-kumo-subtle">
						{formatDuration(narration.audio.durationMs)} · {narration.voice.providerLabel}
						{narration.voice.voiceName ? ` · ${narration.voice.voiceName}` : ""} ·{" "}
						{narration.timing === "word" ? "word timing" : "estimated timing"}
					</p>
					{stale && <Badge variant="warning">Text changed since this audio was made</Badge>}
				</div>
			) : (
				!running && <p className="text-kumo-subtle">No audio yet.</p>
			)}

			{running && (
				<div className="grid gap-2" aria-live="polite">
					<Meter
						label={status.data.job.finalizing ? "Joining audio…" : `Generating ${status.data.job.done + 1} of ${status.data.job.total}…`}
						value={status.data.job.total ? (status.data.job.done / status.data.job.total) * 100 : 0}
					/>
					{status.data.job.error && <p className="text-xs text-kumo-subtle">Retrying: {status.data.job.error}</p>}
					<Button size="sm" variant="ghost" onClick={() => run("cancel")}>Cancel</Button>
				</div>
			)}

			{failed && (
				<div className="grid gap-2">
					<p role="alert" className="text-kumo-danger">{status.data.job.error}</p>
					<div className="flex flex-wrap gap-2">
						<Button size="sm" variant="primary" disabled={action.isPending} onClick={() => run("generate", { resume: true })}>
							Retry from chunk {status.data.job.done + 1}
						</Button>
						<Button size="sm" variant="secondary" disabled={action.isPending} onClick={() => run("cancel")}>Discard</Button>
					</div>
				</div>
			)}

			{action.isError && <p role="alert" className="text-kumo-danger">{errorMessage(action.error)}</p>}

			<div className="grid gap-1">
				<p className="text-xs text-kumo-subtle">
					{voice.providerLabel}
					{voice.voiceName || voice.voiceId ? ` · ${voice.voiceName ?? voice.voiceId}` : " · no voice chosen"}
					{voice.model ? ` · ${voice.model}` : ""}
				</p>
				<p className="text-xs text-kumo-subtle">
					{number.format(source.chars)} characters in {source.blocks} blocks
					{voice.timing === "estimated" ? " · timing will be estimated" : ""}
				</p>
				{!source.published && <p className="text-xs text-kumo-subtle">Visitors hear it once the entry is published.</p>}
				{!voice.configured && <p className="text-xs text-kumo-danger">{voice.providerLabel} needs credentials in the plugin settings.</p>}
			</div>

			<div className="flex flex-wrap gap-2">
				<Button
					size="sm"
					variant="primary"
					loading={action.isPending && action.variables?.route === "generate"}
					disabled={busy || failed || !voice.configured || !voice.voiceId || source.blocks === 0}
					onClick={() => run("generate")}
				>
					{narration ? "Regenerate" : "Generate audio"}
				</Button>
				<Button size="sm" variant="secondary" disabled={busy} onClick={() => setScriptOpen(true)}>
					Voice &amp; script
				</Button>
				{narration && (
					<DeleteButton disabled={busy} onConfirm={() => run("remove")} />
				)}
			</div>

			{scriptOpen && (
				<ScriptDialog
					collection={collection}
					id={id}
					onClose={(changed) => {
						setScriptOpen(false);
						if (changed) void queryClient.invalidateQueries({ queryKey: statusKey });
					}}
				/>
			)}
		</div>
	);
}

function DeleteButton({ disabled, onConfirm }: { disabled: boolean; onConfirm: () => void }) {
	return (
		<Dialog.Root role="alertdialog">
			<Dialog.Trigger render={(props) => <Button {...props} size="sm" variant="ghost" disabled={disabled}>Delete audio</Button>} />
			<Dialog className="grid gap-4 p-6">
				<Dialog.Title className="text-lg font-semibold">Delete this audio?</Dialog.Title>
				<Dialog.Description>The MP3 is removed from the media library and the player disappears from the page. Generating it again is billed again.</Dialog.Description>
				<div className="flex justify-end gap-2">
					<Dialog.Close render={(props) => <Button {...props} variant="secondary">Cancel</Button>} />
					<Dialog.Close render={(props) => <Button {...props} variant="destructive" onClick={onConfirm}>Delete</Button>} />
				</div>
			</Dialog>
		</Dialog.Root>
	);
}

const SPEEDS = [0.8, 0.9, 1, 1.1, 1.2];
const KIND_LABEL: Record<string, string> = { title: "Title", heading: "Heading", paragraph: "Paragraph", quote: "Quote", "list-item": "List item" };

function ScriptDialog({ collection, id, onClose }: { collection: string; id: string; onClose: (changed: boolean) => void }) {
	const script = useQuery({ queryKey: ["article-audio", "script", collection, id], queryFn: () => get<ScriptData>("script", { collection, id }), staleTime: 0 });
	const [provider, setProvider] = useState<string | null>(null);
	const [voiceId, setVoiceId] = useState<string | null>(null);
	const [model, setModel] = useState<string | null>(null);
	const [speed, setSpeed] = useState<number | null>(null);
	const [edits, setEdits] = useState<Record<string, string | null>>({});
	const focused = useRef<{ key: string; el: HTMLTextAreaElement } | null>(null);

	const data = script.data;
	const activeProvider = provider ?? data?.voice.provider ?? "";
	const providerInfo = data?.providers.find((p) => p.id === activeProvider);
	const providerChanged = Boolean(data && activeProvider !== data.voice.provider);
	const activeVoice = voiceId ?? (providerChanged ? "" : (data?.voice.voiceId ?? ""));
	const activeModel = model ?? (providerChanged ? (providerInfo?.models[0]?.id ?? null) : (data?.voice.model ?? null));
	const tagsRead = providerInfo?.models.find((m) => m.id === activeModel)?.tags ?? false;

	const voices = useQuery({
		queryKey: ["article-audio", "voices", activeProvider],
		queryFn: () => get<VoiceList>("voices", { provider: activeProvider }),
		enabled: Boolean(activeProvider && providerInfo?.configured),
		staleTime: 5 * 60_000,
	});

	const save = useMutation({
		mutationFn: () => {
			const overrides: Record<string, string | null> = {};
			for (const block of data?.blocks ?? []) {
				const edit = Object.hasOwn(edits, block.key) ? edits[block.key] : block.skipped ? null : (block.script ?? "");
				if (edit === null) overrides[block.key] = null;
				else if (typeof edit === "string" && edit.trim() && edit.trim() !== block.text.trim()) overrides[block.key] = edit;
			}
			const voice = voices.data?.voices.find((v) => v.id === activeVoice);
			return post<ScriptData>("save-script", {
				collection,
				id,
				overrides,
				provider: activeProvider,
				voiceId: activeVoice,
				voiceName: voice?.name ?? (activeVoice === data?.voice.voiceId ? data?.voice.voiceName : null) ?? "",
				model: activeModel ?? "",
				speed: speed ?? data?.voice.speed ?? 1,
			});
		},
		onSuccess: () => onClose(true),
	});

	const insertTag = (tag: string) => {
		const target = focused.current;
		if (!target || !data) return;
		const block = data.blocks.find((b) => b.key === target.key);
		const current = (Object.hasOwn(edits, target.key) ? edits[target.key] : block?.script) || block?.text || "";
		const at = target.el.value ? (target.el.selectionStart ?? current.length) : 0;
		const next = `${current.slice(0, at)}[${tag}] ${current.slice(at)}`;
		setEdits((prev) => ({ ...prev, [target.key]: next }));
		requestAnimationFrame(() => {
			target.el.focus();
			target.el.setSelectionRange(at + tag.length + 3, at + tag.length + 3);
		});
	};

	return (
		<Dialog.Root open onOpenChange={(open) => !open && onClose(false)}>
			<Dialog size="xl" className="flex max-h-[85dvh] max-w-[calc(100vw-2rem)] flex-col gap-4 overflow-hidden p-6">
				<div className="grid gap-1">
					<Dialog.Title className="text-lg font-semibold">Voice &amp; script</Dialog.Title>
					<Dialog.Description>
						Change what is read without changing the page. Leave a block empty to read it as written.
					</Dialog.Description>
				</div>

				<div className="grid min-h-0 flex-1 content-start gap-4 overflow-y-auto pe-1">
					{script.isPending && <p className="text-sm text-kumo-subtle">Loading…</p>}
					{script.isError && <p role="alert" className="text-sm text-kumo-danger">{errorMessage(script.error)}</p>}
					{data && (
						<>
							<div className="grid gap-3 sm:grid-cols-2">
								<Select
									label="Engine"
									value={activeProvider}
									renderValue={(value) => data.providers.find((p) => p.id === value)?.label ?? String(value)}
									onValueChange={(value) => {
										if (typeof value !== "string") return;
										setProvider(value);
										setVoiceId(null);
										setModel(null);
									}}
								>
									{data.providers.map((p) => (
										<Select.Option key={p.id} value={p.id}>
											{p.label}
											{p.configured ? "" : " (not set up)"}
										</Select.Option>
									))}
								</Select>
								<Select
									label="Voice"
									placeholder={voices.isFetching ? "Loading voices…" : "Choose a voice"}
									value={activeVoice || null}
									disabled={!providerInfo?.configured}
									renderValue={(value) =>
										voices.data?.voices.find((v) => v.id === value)?.name ?? (value === data.voice.voiceId ? data.voice.voiceName : null) ?? String(value)
									}
									onValueChange={(value) => typeof value === "string" && setVoiceId(value)}
								>
									{activeVoice && !voices.data?.voices.some((v) => v.id === activeVoice) && (
										<Select.Option value={activeVoice}>{data.voice.voiceName ?? activeVoice}</Select.Option>
									)}
									{voices.data?.voices.map((voice) => (
										<Select.Option key={voice.id} value={voice.id}>
											{voice.name}
											{voice.description ? ` — ${voice.description}` : ""}
										</Select.Option>
									))}
								</Select>
								{providerInfo && providerInfo.models.length > 0 && (
									<Select
										label="Model"
										value={activeModel}
										renderValue={(value) => providerInfo.models.find((m) => m.id === value)?.label ?? String(value)}
										onValueChange={(value) => typeof value === "string" && setModel(value)}
									>
										{providerInfo.models.map((m) => (
											<Select.Option key={m.id} value={m.id}>{m.label}</Select.Option>
										))}
									</Select>
								)}
								<Select
									label="Speed"
									value={String(speed ?? data.voice.speed ?? 1)}
									renderValue={(value) => (Number(value) === 1 ? "Normal" : `${value}×`)}
									onValueChange={(value) => typeof value === "string" && setSpeed(Number(value))}
								>
									{SPEEDS.map((s) => (
										<Select.Option key={s} value={String(s)}>{s === 1 ? "Normal" : `${s}×`}</Select.Option>
									))}
								</Select>
							</div>
							{voices.isError && <p role="alert" className="text-sm text-kumo-danger">{errorMessage(voices.error)}</p>}
							{(() => {
								const preview = voices.data?.voices.find((v) => v.id === activeVoice)?.previewUrl;
								return preview ? <audio controls preload="none" src={preview} className="w-full" aria-label="Voice preview" /> : null;
							})()}

							<div className="grid gap-2">
								<p className="text-sm font-medium">Expression tags</p>
								<p className="text-xs text-kumo-subtle">
									{tagsRead
										? "This model reads [tags] as delivery cues. Click a text box, then a tag."
										: "This model only understands [pause]; other tags are left out. Eleven v4 and v3 read every tag."}
								</p>
								<div className="flex flex-wrap gap-1.5">
									{data.tags.map((tag) => (
										<Button key={tag} size="xs" variant="outline" onMouseDown={(event) => event.preventDefault()} onClick={() => insertTag(tag)}>
											[{tag}]
										</Button>
									))}
								</div>
							</div>

							<ol className="grid gap-4">
								{data.blocks.map((block) => {
									const edit = Object.hasOwn(edits, block.key) ? edits[block.key] : block.skipped ? null : (block.script ?? "");
									const skipped = edit === null;
									return (
										<li key={block.key} className="grid gap-1.5 rounded-lg border border-kumo-line p-3">
											<div className="flex items-center justify-between gap-2">
												<span className="text-xs font-medium uppercase tracking-wide text-kumo-subtle">{KIND_LABEL[block.kind] ?? block.kind}</span>
												<Switch
													label="Read"
													checked={!skipped}
													onCheckedChange={(checked) => setEdits((prev) => ({ ...prev, [block.key]: checked ? (block.script ?? "") : null }))}
												/>
											</div>
											{skipped ? (
												<p className="text-sm text-kumo-subtle line-through">{block.text}</p>
											) : (
												<Textarea
													aria-label={`Script for ${KIND_LABEL[block.kind] ?? "block"}`}
													rows={Math.min(8, Math.max(2, Math.ceil(block.text.length / 90)))}
													placeholder={block.text}
													value={edit ?? ""}
													onFocus={(event) => (focused.current = { key: block.key, el: event.currentTarget })}
													onValueChange={(value) => setEdits((prev) => ({ ...prev, [block.key]: value }))}
												/>
											)}
										</li>
									);
								})}
							</ol>
						</>
					)}
				</div>

				<div className="grid gap-2">
					{save.isError && <Banner variant="error" title="Not saved" description={errorMessage(save.error)} />}
					<div className="flex justify-end gap-2">
						<Dialog.Close render={(props) => <Button {...props} variant="secondary">Cancel</Button>} />
						<Button variant="primary" loading={save.isPending} disabled={!data || !activeVoice} onClick={() => save.mutate()}>
							Save
						</Button>
					</div>
				</div>
			</Dialog>
		</Dialog.Root>
	);
}

export const contentEditorPanels = [
	{
		id: "audio",
		title: "Audio",
		component: AudioPanel,
		// Which collections have audio is a setting, so the panel asks the server and explains when it is off.
		minRole: 40,
		order: 40,
	},
] satisfies readonly ContentEditorPanelExtension[];
