/**
 * Public narration contract and player helpers.
 *
 * Framework-free and dependency-free: import it from a website, a React
 * Native app or a server. `GET /_emdash/api/plugins/article-audio/narration`
 * returns `{ success: true, data: Narration }`.
 */

export const NARRATION_FORMAT = 1 as const;

export type NarrationBlockKind = "title" | "heading" | "paragraph" | "quote" | "list-item";

/** `word`: the engine reported when each word was spoken. `estimated`: spread by text length. */
export type NarrationTiming = "word" | "estimated";

export interface NarrationBlock {
	/** Portable Text `_key` of the block, or `title` / `excerpt` for those fields. */
	key: string;
	kind: NarrationBlockKind;
	/** Text as rendered on the page. Words are its whitespace-separated tokens. */
	text: string;
	startMs: number;
	endMs: number;
	/** `[start0, end0, start1, end1, …]` in ms from the start of the audio, one pair per word of `text`. */
	words: number[];
}

export interface Narration {
	format: typeof NARRATION_FORMAT;
	collection: string;
	contentId: string;
	locale: string | null;
	audio: {
		/** Absolute URL of the MP3; supports HTTP range requests. */
		url: string;
		mimeType: "audio/mpeg";
		durationMs: number;
		bytes: number;
	};
	voice: {
		provider: string;
		providerLabel: string;
		voiceId: string;
		voiceName: string | null;
		model: string | null;
	};
	timing: NarrationTiming;
	/** Changes whenever the narrated text changes. */
	sourceHash: string;
	generatedAt: string;
	blocks: NarrationBlock[];
}

export interface NarrationPosition {
	/** Index into `blocks`. */
	block: number;
	/** Index of the word inside the block, or -1 between words. */
	word: number;
}

/** Word count of a block: its `\S+` tokens. Same rule the server used. */
export function wordCount(block: NarrationBlock): number {
	return block.words.length / 2;
}

/** The block and word being spoken at `timeMs` (binary search; O(log n)). */
export function positionAt(narration: Pick<Narration, "blocks">, timeMs: number): NarrationPosition | null {
	const { blocks } = narration;
	let lo = 0;
	let hi = blocks.length - 1;
	let found = -1;
	while (lo <= hi) {
		const mid = (lo + hi) >> 1;
		if (blocks[mid].startMs <= timeMs) {
			found = mid;
			lo = mid + 1;
		} else hi = mid - 1;
	}
	if (found < 0) return null;
	const block = blocks[found];
	if (timeMs > block.endMs + 1500) return null; // in a long pause after the block
	const words = block.words;
	let wlo = 0;
	let whi = words.length / 2 - 1;
	let word = -1;
	while (wlo <= whi) {
		const mid = (wlo + whi) >> 1;
		if (words[mid * 2] <= timeMs) {
			word = mid;
			wlo = mid + 1;
		} else whi = mid - 1;
	}
	if (word >= 0 && timeMs > words[word * 2 + 1] + 250 && word === words.length / 2 - 1) word = -1;
	return { block: found, word };
}

/** Start time of a word, for "play from here". */
export function wordStartMs(narration: Pick<Narration, "blocks">, block: number, word = 0): number | null {
	const target = narration.blocks[block];
	if (!target) return null;
	return target.words[word * 2] ?? target.startMs;
}

/** Character ranges of each word in a block's text, matching the server's tokenisation. */
export function wordRanges(text: string): Array<[start: number, end: number]> {
	return Array.from(text.matchAll(/\S+/g), (match) => [match.index, match.index + match[0].length]);
}

/** Collapses whitespace for comparing a block's text with a rendered element's text. */
export function normalizeText(text: string): string {
	return text.replace(/\s+/g, " ").trim();
}

export function isNarration(value: unknown): value is Narration {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value as Partial<Narration>;
	return candidate.format === NARRATION_FORMAT && typeof candidate.audio?.url === "string" && Array.isArray(candidate.blocks);
}
