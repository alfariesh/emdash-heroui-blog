/**
 * From engine timestamps to page highlights.
 *
 * 1. `chunkTimeline` turns one chunk's timing into spoken words per block,
 *    in milliseconds from the start of that chunk. Engines without
 *    timestamps get an estimate spread by character count.
 * 2. `buildBlocks` joins the timelines of every chunk, then matches the
 *    spoken words of each block to its written words (longest common
 *    subsequence on normalised words). Matched words take the engine's
 *    times; words the script changed or skipped are interpolated, so the
 *    highlight still moves smoothly when an editor rewrote a sentence.
 */
import type { ChunkPlan } from "./chunk.ts";
import type { ChunkTiming, SpokenWord } from "./render.ts";
import { normalizeWord, tokenize, type SourceBlock } from "./text.ts";

/** `[word, startMs, endMs]`, relative to the chunk (or, once offset, to the audio). */
export type TimedWord = [text: string, startMs: number, endMs: number];

export interface BlockTimeline {
	block: number;
	words: TimedWord[];
}

/** Weight of a segment break in estimated timing, in characters. */
const BREAK_WEIGHT = 12;

function spokenText(plan: ChunkPlan, index: number): string {
	return plan.segments[index].pieces.map((piece) => (piece.kind === "text" ? piece.text : " ")).join("");
}

function estimateTiming(plan: ChunkPlan, durationMs: number): SpokenWord[][] {
	const segmentWords = plan.segments.map((_, index) => tokenize(spokenText(plan, index)));
	const weight = segmentWords.reduce(
		(sum, words) => sum + BREAK_WEIGHT + words.reduce((acc, word) => acc + word.text.length + 1, 0),
		0,
	);
	const perUnit = weight > 0 ? durationMs / 1000 / weight : 0;
	let cursor = 0;
	return segmentWords.map((words) => {
		const timed = words.map((word) => {
			const start = cursor;
			cursor += (word.text.length + 1) * perUnit;
			return { text: word.text, start, end: cursor - perUnit * 0.5 };
		});
		cursor += BREAK_WEIGHT * perUnit;
		return timed;
	});
}

/** Fills words the engine left untimed from their neighbours. */
function fillGaps(words: SpokenWord[], floor: number, ceiling: number) {
	// Half-timed words: an end runs to the next known start, a start follows the previous end.
	for (let i = 0; i < words.length; i++) {
		const word = words[i];
		if (Number.isFinite(word.start) && !Number.isFinite(word.end)) {
			const next = words.slice(i + 1).find((w) => Number.isFinite(w.start));
			word.end = Math.max(word.start, next ? next.start : ceiling);
		} else if (!Number.isFinite(word.start) && Number.isFinite(word.end)) {
			const previous = words.slice(0, i).findLast((w) => Number.isFinite(w.end));
			word.start = Math.min(word.end, previous ? previous.end : floor);
		}
	}
	let previousEnd = floor;
	for (let i = 0; i < words.length; i++) {
		const word = words[i];
		if (Number.isFinite(word.start) && Number.isFinite(word.end)) {
			previousEnd = word.end;
			continue;
		}
		let next = i;
		while (next < words.length && !(Number.isFinite(words[next].start) && Number.isFinite(words[next].end))) next++;
		const nextStart = next < words.length ? words[next].start : ceiling;
		const span = Math.max(0, nextStart - previousEnd);
		const run = words.slice(i, next);
		const total = run.reduce((sum, w) => sum + w.text.length + 1, 0) || 1;
		let cursor = previousEnd;
		for (const w of run) {
			w.start = cursor;
			cursor += (span * (w.text.length + 1)) / total;
			w.end = cursor;
		}
		previousEnd = cursor;
		i = next - 1;
	}
}

/** Spoken words per block for one chunk, in ms from the chunk's start. */
export function chunkTimeline(plan: ChunkPlan, timing: ChunkTiming, durationMs: number): BlockTimeline[] {
	const perSegment = timing ?? estimateTiming(plan, durationMs);
	const durationS = durationMs / 1000;
	const timelines: BlockTimeline[] = [];
	const firstStart = (index: number) => perSegment[index]?.find((word) => Number.isFinite(word.start))?.start;
	let floor = 0;
	plan.segments.forEach((segment, index) => {
		const words = (perSegment[index] ?? []).map((word) => ({ ...word }));
		let ceiling = durationS;
		for (let next = index + 1; next < plan.segments.length; next++) {
			const start = firstStart(next);
			if (start !== undefined) {
				ceiling = start;
				break;
			}
		}
		fillGaps(words, floor, Math.max(floor, ceiling));
		floor = words.at(-1)?.end ?? floor;
		const timed = words.map((word): TimedWord => [
			word.text,
			Math.round(Math.min(word.start, durationS) * 1000),
			Math.round(Math.min(Math.max(word.end, word.start), durationS) * 1000),
		]);
		const last = timelines.at(-1);
		if (last && last.block === segment.block) last.words.push(...timed);
		else timelines.push({ block: segment.block, words: timed });
	});
	return timelines;
}

export function offsetTimeline(timeline: readonly BlockTimeline[], offsetMs: number): BlockTimeline[] {
	return timeline.map(({ block, words }) => ({
		block,
		words: words.map(([text, start, end]): TimedWord => [text, start + offsetMs, end + offsetMs]),
	}));
}

/** Index pairs [written, spoken] of the longest common subsequence of normalised words. */
export function matchWords(written: readonly string[], spoken: readonly string[]): Array<[number, number]> {
	const a = written.map(normalizeWord);
	const b = spoken.map(normalizeWord);
	const n = a.length;
	const m = b.length;
	if (n === 0 || m === 0) return [];
	if (n * m > 4_000_000) {
		// Too long to compare word by word; pair words by position instead.
		return Array.from({ length: Math.min(n, m) }, (_, i) => [Math.floor((i * n) / Math.min(n, m)), Math.floor((i * m) / Math.min(n, m))]);
	}
	const table = new Uint16Array((n + 1) * (m + 1));
	const at = (i: number, j: number) => i * (m + 1) + j;
	for (let i = n - 1; i >= 0; i--) {
		for (let j = m - 1; j >= 0; j--) {
			table[at(i, j)] = a[i] && a[i] === b[j] ? table[at(i + 1, j + 1)] + 1 : Math.max(table[at(i + 1, j)], table[at(i, j + 1)]);
		}
	}
	const pairs: Array<[number, number]> = [];
	let i = 0;
	let j = 0;
	while (i < n && j < m) {
		if (a[i] && a[i] === b[j]) {
			pairs.push([i, j]);
			i++;
			j++;
		} else if (table[at(i + 1, j)] >= table[at(i, j + 1)]) i++;
		else j++;
	}
	return pairs;
}

export interface NarrationBlock {
	/** Portable Text `_key`, or `title` / `excerpt`. */
	key: string;
	kind: SourceBlock["kind"];
	/** Text as rendered on the page; words are its whitespace-separated tokens. */
	text: string;
	startMs: number;
	endMs: number;
	/** `[start0, end0, start1, end1, …]` in ms, one pair per word of `text`. */
	words: number[];
}

/** Narrated blocks with word timings, from the offset timelines of every chunk. */
export function buildBlocks(blocks: readonly SourceBlock[], timelines: readonly BlockTimeline[]): NarrationBlock[] {
	const spokenByBlock = new Map<number, TimedWord[]>();
	for (const { block, words } of timelines) {
		const list = spokenByBlock.get(block) ?? [];
		list.push(...words);
		spokenByBlock.set(block, list);
	}

	const result: NarrationBlock[] = [];
	for (const [index, spoken] of [...spokenByBlock.entries()].sort((x, y) => x[0] - y[0])) {
		const source = blocks[index];
		if (!source || spoken.length === 0) continue;
		const written = tokenize(source.text);
		const blockStart = spoken[0][1];
		const blockEnd = Math.max(blockStart, spoken.at(-1)![2]);

		const times: Array<[number, number] | null> = written.map(() => null);
		for (const [w, s] of matchWords(
			written.map((word) => word.text),
			spoken.map((word) => word[0]),
		)) {
			times[w] = [spoken[s][1], spoken[s][2]];
		}

		// Interpolate written words that were not matched (edited or normalised by the engine).
		let previousEnd = blockStart;
		for (let i = 0; i < written.length; i++) {
			const time = times[i];
			if (time) {
				previousEnd = Math.max(previousEnd, time[1]);
				continue;
			}
			let next = i;
			while (next < written.length && !times[next]) next++;
			const nextStart = next < written.length ? times[next]![0] : blockEnd;
			const span = Math.max(0, nextStart - previousEnd);
			const run = written.slice(i, next);
			const total = run.reduce((sum, word) => sum + word.text.length + 1, 0) || 1;
			let cursor = previousEnd;
			for (let k = i; k < next; k++) {
				const start = cursor;
				cursor += (span * (written[k].text.length + 1)) / total;
				times[k] = [Math.round(start), Math.round(cursor)];
			}
			previousEnd = cursor;
			i = next - 1;
		}

		result.push({
			key: source.key,
			kind: source.kind,
			text: source.text,
			startMs: blockStart,
			endMs: blockEnd,
			words: times.flatMap((time) => time ?? [blockStart, blockStart]),
		});
	}
	return result;
}
