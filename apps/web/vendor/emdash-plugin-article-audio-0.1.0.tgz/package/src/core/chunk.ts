/**
 * Splits a narration script into provider requests.
 *
 * Every engine caps the characters per request, and a plugin's outbound
 * response is capped at 8 MiB, so long articles are synthesized in chunks
 * and joined afterwards. Chunks break between blocks when they can and
 * between sentences when one block is too long on its own.
 */
import { parseScript, type ScriptPiece } from "./tags.ts";
import type { NarrationBlockKind } from "./text.ts";

export interface PlanSegment {
	/** Index into the narration's blocks. A long block can span several segments. */
	block: number;
	kind: NarrationBlockKind;
	pieces: ScriptPiece[];
}

export interface ChunkPlan {
	segments: PlanSegment[];
	/** Script characters in the chunk, tags included. */
	chars: number;
}

export interface ChunkLimits {
	/** Hard ceiling per request, in script characters. */
	maxChars: number;
	/** Preferred size; chunks grow past it only to keep a block whole. */
	targetChars: number;
	/** Size of a script in the provider's unit (default: characters). */
	measure?: (script: string) => number;
}

export interface ScriptItem {
	block: number;
	kind: NarrationBlockKind;
	script: string;
}

/** Characters between two segments in a request (a paragraph break). */
export const SEGMENT_SEPARATOR = "\n\n";

const SENTENCE_END = /[.!?…。！？]["'”’)\]]*\s+/gu;
const TAG_RANGE = /\[[\p{L}][\p{L}\p{N} .,'_-]{0,48}\]/gu;

const hasSpokenText = (pieces: ScriptPiece[]) => pieces.some((piece) => piece.kind === "text" && piece.text.trim());

/** Cut points in `script` (after a sentence end, never inside a tag). */
function sentenceBreaks(script: string): number[] {
	const tags = Array.from(script.matchAll(TAG_RANGE), (m) => [m.index, m.index + m[0].length] as const);
	const insideTag = (index: number) => tags.some(([start, end]) => index > start && index < end);
	return Array.from(script.matchAll(SENTENCE_END), (m) => m.index + m[0].length).filter((index) => !insideTag(index));
}

/** Splits one over-long script into parts no longer than `max`. */
export function splitScript(script: string, max: number): string[] {
	const parts: string[] = [];
	let rest = script;
	while (rest.length > max) {
		const breaks = sentenceBreaks(rest).filter((index) => index <= max);
		let cut = breaks.at(-1) ?? -1;
		if (cut <= 0) {
			const space = rest.lastIndexOf(" ", max);
			cut = space > 0 ? space + 1 : max;
		}
		parts.push(rest.slice(0, cut).trim());
		rest = rest.slice(cut);
	}
	if (rest.trim()) parts.push(rest.trim());
	return parts.filter(Boolean);
}

export function planChunks(items: readonly ScriptItem[], limits: ChunkLimits): ChunkPlan[] {
	const max = Math.max(200, limits.maxChars);
	const target = Math.min(Math.max(100, limits.targetChars), max);

	const measure = limits.measure ?? ((script: string) => script.length);
	const segments: Array<PlanSegment & { length: number }> = [];
	for (const item of items) {
		const size = measure(item.script);
		// Split by characters, scaled when the provider's unit is larger than a character.
		const parts = size > max ? splitScript(item.script, Math.floor((max * item.script.length) / size)) : [item.script];
		for (const part of parts) {
			const pieces = parseScript(part);
			if (hasSpokenText(pieces)) segments.push({ block: item.block, kind: item.kind, pieces, length: measure(part) });
		}
	}

	const chunks: ChunkPlan[] = [];
	let current: ChunkPlan = { segments: [], chars: 0 };
	for (const { length, ...segment } of segments) {
		const added = (current.segments.length ? SEGMENT_SEPARATOR.length : 0) + length;
		if (current.segments.length && current.chars + added > target) {
			chunks.push(current);
			current = { segments: [], chars: 0 };
		}
		current.chars += (current.segments.length ? SEGMENT_SEPARATOR.length : 0) + length;
		current.segments.push(segment);
	}
	if (current.segments.length) chunks.push(current);
	return chunks;
}

/** Total billable characters, roughly what providers charge for. */
export function countCharacters(chunks: readonly ChunkPlan[]): number {
	return chunks.reduce((sum, chunk) => sum + chunk.chars, 0);
}
