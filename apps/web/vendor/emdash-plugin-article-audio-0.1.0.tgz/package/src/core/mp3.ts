/**
 * Just enough MP3 to join chunks into one file.
 *
 * Long articles are synthesized in several requests. Players handle one
 * file far better than a playlist (seeking, total duration, lock-screen
 * controls), so the parts are joined frame by frame: ID3 tags and the
 * Xing/Info header frame of each part are dropped, because an Info frame
 * describes only its own part and would make players report the first
 * part's length for the whole file. Every engine here returns constant
 * bitrate MP3, whose duration players derive from the file size.
 *
 * Frame durations are counted exactly, so timestamps of later chunks are
 * shifted by the real audio length of the chunks before them.
 */

const BITRATES_KBPS = {
	// [MPEG-1, MPEG-2/2.5] Layer III
	1: [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0],
	2: [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0],
} as const;

const SAMPLE_RATES = {
	3: [44100, 48000, 32000], // MPEG-1
	2: [22050, 24000, 16000], // MPEG-2
	0: [11025, 12000, 8000], // MPEG-2.5
} as const;

export interface FrameHeader {
	/** Bytes in the frame, header included. */
	length: number;
	samples: number;
	sampleRate: number;
	bitrateKbps: number;
	channels: 1 | 2;
	/** Offset of the side info's end, where a Xing/Info tag would start. */
	sideInfoEnd: number;
}

/** Parses the 4-byte header at `offset`; null when it is not a Layer III frame header. */
export function parseFrameHeader(bytes: Uint8Array, offset: number): FrameHeader | null {
	if (offset + 4 > bytes.length) return null;
	const b1 = bytes[offset + 1];
	const b2 = bytes[offset + 2];
	const b3 = bytes[offset + 3];
	if (bytes[offset] !== 0xff || (b1 & 0xe0) !== 0xe0) return null;
	const version = (b1 >> 3) & 0x03; // 3 = MPEG-1, 2 = MPEG-2, 0 = MPEG-2.5
	const layer = (b1 >> 1) & 0x03; // 1 = Layer III
	if (version === 1 || layer !== 1) return null;
	const bitrateIndex = (b2 >> 4) & 0x0f;
	const rateIndex = (b2 >> 2) & 0x03;
	if (bitrateIndex === 0 || bitrateIndex === 15 || rateIndex === 3) return null;
	const padding = (b2 >> 1) & 0x01;
	const mpeg1 = version === 3;
	const bitrateKbps = BITRATES_KBPS[mpeg1 ? 1 : 2][bitrateIndex];
	const sampleRate = SAMPLE_RATES[version as 0 | 2 | 3][rateIndex];
	const samples = mpeg1 ? 1152 : 576;
	const length = Math.floor(((mpeg1 ? 144 : 72) * bitrateKbps * 1000) / sampleRate) + padding;
	const channels = ((b3 >> 6) & 0x03) === 3 ? 1 : 2;
	const sideInfo = mpeg1 ? (channels === 1 ? 17 : 32) : channels === 1 ? 9 : 17;
	const crc = (b1 & 0x01) === 0 ? 2 : 0;
	return { length, samples, sampleRate, bitrateKbps, channels, sideInfoEnd: offset + 4 + crc + sideInfo };
}

/** Offset of the first byte after leading ID3v2 tags. */
function skipId3v2(bytes: Uint8Array): number {
	let offset = 0;
	while (offset + 10 <= bytes.length && bytes[offset] === 0x49 && bytes[offset + 1] === 0x44 && bytes[offset + 2] === 0x33) {
		const size = ((bytes[offset + 6] & 0x7f) << 21) | ((bytes[offset + 7] & 0x7f) << 14) | ((bytes[offset + 8] & 0x7f) << 7) | (bytes[offset + 9] & 0x7f);
		const footer = (bytes[offset + 5] & 0x10) !== 0 ? 10 : 0;
		offset += 10 + size + footer;
	}
	return offset;
}

function isInfoFrame(bytes: Uint8Array, header: FrameHeader, offset: number): boolean {
	const tag = (at: number) => String.fromCharCode(bytes[at], bytes[at + 1], bytes[at + 2], bytes[at + 3]);
	const xing = header.sideInfoEnd;
	if (xing + 4 <= bytes.length && (tag(xing) === "Xing" || tag(xing) === "Info")) return true;
	const vbri = offset + 36;
	return vbri + 4 <= bytes.length && tag(vbri) === "VBRI";
}

export interface Mp3Frames {
	/** Audio frames only, without tags or Info header. */
	frames: Array<[start: number, end: number]>;
	durationMs: number;
	sampleRate: number | null;
	bytes: number;
}

/** Finds the audio frames of one MP3 file. Garbage between frames is skipped. */
export function scanMp3(bytes: Uint8Array): Mp3Frames {
	let offset = skipId3v2(bytes);
	let end = bytes.length;
	if (end - 128 >= offset && bytes[end - 128] === 0x54 && bytes[end - 127] === 0x41 && bytes[end - 126] === 0x47) end -= 128;

	const frames: Array<[number, number]> = [];
	let samples = 0;
	let sampleRate: number | null = null;
	let size = 0;
	let first = true;
	while (offset + 4 <= end) {
		const header = parseFrameHeader(bytes, offset);
		const next = header ? offset + header.length : -1;
		// A real frame is followed by another frame or by the end of the data.
		if (!header || next > end || (next + 4 <= end && !parseFrameHeader(bytes, next))) {
			offset++;
			continue;
		}
		if (!(first && isInfoFrame(bytes, header, offset))) {
			frames.push([offset, next]);
			samples += header.samples;
			sampleRate ??= header.sampleRate;
			size += header.length;
		}
		first = false;
		offset = next;
	}
	return { frames, durationMs: sampleRate ? (samples / sampleRate) * 1000 : 0, sampleRate, bytes: size };
}

export function mp3DurationMs(bytes: Uint8Array): number {
	return scanMp3(bytes).durationMs;
}

/** Joins MP3 parts into one stream. Returns each part's exact duration for timestamp offsets. */
export function concatMp3(parts: readonly Uint8Array[]): { bytes: Uint8Array; durationMs: number; partDurationsMs: number[] } {
	const scans = parts.map(scanMp3);
	const total = scans.reduce((sum, scan) => sum + scan.bytes, 0);
	const out = new Uint8Array(total);
	let cursor = 0;
	scans.forEach((scan, index) => {
		for (const [start, end] of scan.frames) {
			out.set(parts[index].subarray(start, end), cursor);
			cursor += end - start;
		}
	});
	const partDurationsMs = scans.map((scan) => scan.durationMs);
	return { bytes: out, durationMs: partDurationsMs.reduce((a, b) => a + b, 0), partDurationsMs };
}

/**
 * Silent constant-bitrate MP3 (MPEG-1 Layer III, 44.1 kHz, 64 kbps, mono)
 * of at least `durationMs`. A frame with zeroed side info decodes as
 * silence in every decoder. Used by the keyless "silent preview" provider.
 */
export function silentMp3(durationMs: number): Uint8Array {
	const exact = (144 * 64_000) / 44_100; // 208.98 bytes per frame
	const count = Math.max(1, Math.ceil(((durationMs / 1000) * 44_100) / 1152));
	// Pad frames like an encoder does, so size / bitrate (how players estimate CBR length) is exact.
	const lengths: number[] = [];
	let carry = 0;
	for (let i = 0; i < count; i++) {
		carry += exact - Math.floor(exact);
		const padded = carry >= 1;
		if (padded) carry -= 1;
		lengths.push(Math.floor(exact) + (padded ? 1 : 0));
	}
	const out = new Uint8Array(lengths.reduce((a, b) => a + b, 0));
	let at = 0;
	for (const length of lengths) {
		out[at] = 0xff;
		out[at + 1] = 0xfb; // MPEG-1, Layer III, no CRC
		out[at + 2] = length > Math.floor(exact) ? 0x52 : 0x50; // 64 kbps, 44.1 kHz, padding bit
		out[at + 3] = 0xc4; // mono, original
		at += length;
	}
	return out;
}
