/**
 * Plain-text rendering of a chunk for engines that take text and return
 * per-character timestamps (ElevenLabs and similar). The rendering keeps a
 * mask from each character to the segment it speaks, so timestamps can be
 * folded back into words without counting tags, breaks or separators.
 */
import { SEGMENT_SEPARATOR, type ChunkPlan } from "./chunk.ts";
import type { ScriptPiece } from "./tags.ts";

/** A word the engine spoke, in seconds from the start of the chunk's audio. */
export interface SpokenWord {
	text: string;
	start: number;
	end: number;
}

/** Spoken words per plan segment, or null when the engine gives no timestamps. */
export type ChunkTiming = SpokenWord[][] | null;

export interface RenderedText {
	text: string;
	/** Code points of `text`. */
	chars: string[];
	/** Segment index per code point; -1 for markup (tags, breaks, separators). */
	segmentOf: Int32Array;
}

export type TagRenderer = (tag: Extract<ScriptPiece, { kind: "tag" }>) => string | null;

const TERMINAL = /[.!?…:;。！？]["'”’)\]]*$/u;

export function renderPlainText(plan: ChunkPlan, renderTag: TagRenderer): RenderedText {
	const chars: string[] = [];
	const owners: number[] = [];
	const append = (text: string, owner: number) => {
		for (const char of text) {
			chars.push(char);
			owners.push(owner);
		}
	};

	plan.segments.forEach((segment, index) => {
		if (index > 0) append(SEGMENT_SEPARATOR, -1);
		let spoken = "";
		for (const piece of segment.pieces) {
			if (piece.kind === "text") {
				append(piece.text, index);
				spoken += piece.text;
			} else {
				const rendered = renderTag(piece);
				if (rendered) append(rendered, -1);
			}
		}
		// Titles and headings rarely end in punctuation; a full stop gives them a pause.
		if ((segment.kind === "title" || segment.kind === "heading") && !TERMINAL.test(spoken.trimEnd())) append(".", -1);
	});

	return { text: chars.join(""), chars, segmentOf: Int32Array.from(owners) };
}

/**
 * Maps an engine's character alignment onto the rendered text. Engines echo
 * the input characters, but may normalise a few; matching resynchronises
 * within a short window, and unmatched characters keep no time (NaN).
 */
export function mapAlignment(rendered: RenderedText, characters: readonly string[], starts: readonly number[], ends: readonly number[]) {
	const n = rendered.chars.length;
	const start = new Float64Array(n).fill(Number.NaN);
	const end = new Float64Array(n).fill(Number.NaN);
	const m = Math.min(characters.length, starts.length, ends.length);
	let i = 0;
	let j = 0;
	while (i < n && j < m) {
		if (rendered.chars[i] === characters[j]) {
			start[i] = starts[j];
			end[i] = ends[j];
			i++;
			j++;
			continue;
		}
		// Find the nearest point where both sides agree again for a few characters:
		// covers dropped tags, expanded numbers and normalised punctuation.
		const skip = resync(rendered.chars, characters, i, j, n, m);
		if (skip) {
			i += skip[0];
			j += skip[1];
		} else {
			i++;
			j++;
		}
	}
	return { start, end };
}

const RESYNC_WINDOW = 48;
const RESYNC_RUN = 3;

function resync(a: readonly string[], b: readonly string[], i: number, j: number, n: number, m: number): [number, number] | null {
	for (let distance = 1; distance <= RESYNC_WINDOW; distance++) {
		for (let di = 0; di <= distance; di++) {
			const dj = distance - di;
			if (i + di >= n || j + dj >= m) continue;
			let run = 0;
			while (run < RESYNC_RUN && i + di + run < n && j + dj + run < m && a[i + di + run] === b[j + dj + run]) run++;
			if (run === RESYNC_RUN || (run > 0 && (i + di + run === n || j + dj + run === m))) return [di, dj];
		}
	}
	return null;
}

/** Folds per-character times into the spoken words of each segment. */
export function wordsFromCharTimes(rendered: RenderedText, start: Float64Array, end: Float64Array, segmentCount: number): SpokenWord[][] {
	const words: SpokenWord[][] = Array.from({ length: segmentCount }, () => []);
	let current: { segment: number; text: string; start: number; end: number } | null = null;
	const flush = () => {
		if (current && current.text) {
			words[current.segment].push({ text: current.text, start: current.start, end: current.end });
		}
		current = null;
	};

	for (let i = 0; i < rendered.chars.length; i++) {
		const segment = rendered.segmentOf[i];
		const char = rendered.chars[i];
		if (segment < 0 || /\s/u.test(char)) {
			flush();
			continue;
		}
		if (current && current.segment !== segment) flush();
		current ??= { segment, text: "", start: Number.NaN, end: Number.NaN };
		current.text += char;
		if (!Number.isNaN(start[i])) current.start = Number.isNaN(current.start) ? start[i] : Math.min(current.start, start[i]);
		if (!Number.isNaN(end[i])) current.end = Number.isNaN(current.end) ? end[i] : Math.max(current.end, end[i]);
	}
	flush();
	return words;
}
