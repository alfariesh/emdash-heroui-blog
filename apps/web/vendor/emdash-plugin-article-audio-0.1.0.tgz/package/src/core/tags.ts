/**
 * Expression tags in a narration script.
 *
 * Editors write delivery cues in square brackets, the syntax ElevenLabs v3
 * reads natively: `[whispers]`, `[laughs]`, `[excited]`, `[sighs]`,
 * `[pause]`, `[pause 1.5s]`. A tag is never part of the page text, so it is
 * never highlighted. Each provider decides what to do with a tag: pass it
 * through, turn a pause into a break, or drop it.
 *
 * Only brackets that start with a letter are tags, so citations such as
 * `[1]` stay text.
 */

export type ScriptPiece = { kind: "text"; text: string } | { kind: "tag"; name: string; raw: string };

const TAG = /\[([\p{L}][\p{L}\p{N} .,'_-]{0,48})\]/gu;

/** Splits a script into text and tag pieces, in order. */
export function parseScript(script: string): ScriptPiece[] {
	const pieces: ScriptPiece[] = [];
	let last = 0;
	for (const match of script.matchAll(TAG)) {
		if (match.index > last) pieces.push({ kind: "text", text: script.slice(last, match.index) });
		pieces.push({ kind: "tag", name: match[1].trim().toLowerCase(), raw: match[0] });
		last = match.index + match[0].length;
	}
	if (last < script.length) pieces.push({ kind: "text", text: script.slice(last) });
	return pieces;
}

/** The script without tags, with the gaps they leave collapsed. */
export function stripTags(script: string): string {
	return parseScript(script)
		.map((piece) => (piece.kind === "text" ? piece.text : " "))
		.join("")
		.replace(/[ \t]{2,}/g, " ")
		.trim();
}

export function hasTags(script: string): boolean {
	return parseScript(script).some((piece) => piece.kind === "tag");
}

const PAUSE = /^(?:(short|long)\s+)?(?:pause|break)(?:\s+(\d+(?:\.\d+)?)\s*(ms|s)?)?$/;

/**
 * Seconds of silence for a pause tag, or null when the tag is not a pause.
 * `[pause]` = 0.75 s, `[short pause]` = 0.4 s, `[long pause]` = 1.5 s,
 * `[pause 2s]` / `[pause 300ms]` = as written (capped at 3 s, the longest
 * break most engines accept).
 */
export function pauseSeconds(name: string): number | null {
	const match = PAUSE.exec(name);
	if (!match) return null;
	const [, size, amount, unit] = match;
	let seconds = size === "short" ? 0.4 : size === "long" ? 1.5 : 0.75;
	if (amount) seconds = unit === "ms" ? Number(amount) / 1000 : Number(amount);
	return Math.min(Math.max(seconds, 0.1), 3);
}

/**
 * Suggested cues for the script editor. ElevenLabs v3 understands far more;
 * these are the ones that read well in articles.
 */
export const SUGGESTED_TAGS = [
	"pause",
	"long pause",
	"excited",
	"curious",
	"serious",
	"sarcastic",
	"whispers",
	"laughs",
	"sighs",
	"clears throat",
] as const;
