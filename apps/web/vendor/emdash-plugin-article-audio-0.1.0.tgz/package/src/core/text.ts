/**
 * Turns an entry into the blocks a listener hears and a reader sees.
 *
 * A narration block is one rendered text element on the page: the title, a
 * paragraph, a heading, a quote, or a list item. Its `text` is exactly what
 * the page renders (the concatenated span text of a Portable Text block), so
 * a player can find the element again and highlight its words. Images, code,
 * embeds and other non-text blocks are not narrated.
 */

export type NarrationBlockKind = "title" | "heading" | "paragraph" | "quote" | "list-item";

export interface SourceBlock {
	/** Portable Text `_key`, or `title` / `excerpt` for those entry fields. */
	key: string;
	kind: NarrationBlockKind;
	/** Display text exactly as rendered. */
	text: string;
}

export interface ExtractOptions {
	/** Field names to try for the body, in order. The first Portable Text array wins. */
	bodyFields?: readonly string[];
	includeTitle?: boolean;
	includeExcerpt?: boolean;
}

export const DEFAULT_BODY_FIELDS = ["content", "body"] as const;

const isRecord = (value: unknown): value is Record<string, unknown> =>
	typeof value === "object" && value !== null && !Array.isArray(value);

const HEADING_STYLE = /^h[1-6]$/;

function blockKind(block: Record<string, unknown>): NarrationBlockKind {
	if (typeof block.listItem === "string" && block.listItem) return "list-item";
	const style = typeof block.style === "string" ? block.style : "normal";
	if (HEADING_STYLE.test(style)) return "heading";
	if (style === "blockquote") return "quote";
	return "paragraph";
}

/** Concatenated text of a Portable Text block's spans; inline objects without text add nothing. */
export function blockText(block: Record<string, unknown>): string {
	const children = Array.isArray(block.children) ? block.children : [];
	let text = "";
	for (const child of children) {
		if (isRecord(child) && typeof child.text === "string") text += child.text;
	}
	return text;
}

function isPortableText(value: unknown): value is unknown[] {
	return Array.isArray(value) && value.some((item) => isRecord(item) && typeof item._type === "string");
}

/** The first configured field holding a Portable Text array. */
export function findBody(data: Record<string, unknown>, fields: readonly string[] = DEFAULT_BODY_FIELDS) {
	for (const field of fields) {
		const value = data[field];
		if (isPortableText(value)) return { field, value };
	}
	return null;
}

export function extractBlocks(data: Record<string, unknown>, options: ExtractOptions = {}): SourceBlock[] {
	const blocks: SourceBlock[] = [];
	const push = (key: string, kind: NarrationBlockKind, text: unknown) => {
		if (typeof text === "string" && text.trim()) blocks.push({ key, kind, text });
	};

	if (options.includeTitle !== false) push("title", "title", data.title);
	if (options.includeExcerpt) push("excerpt", "paragraph", data.excerpt);

	const body = findBody(data, options.bodyFields ?? DEFAULT_BODY_FIELDS);
	if (!body) return blocks;

	body.value.forEach((item, index) => {
		if (!isRecord(item) || item._type !== "block") return;
		const key = typeof item._key === "string" && item._key ? item._key : `block-${index}`;
		push(key, blockKind(item), blockText(item));
	});
	return blocks;
}

export interface WordToken {
	text: string;
	start: number;
	end: number;
}

/**
 * Words are whitespace-separated tokens. Players use the same rule on the
 * element's text, so word `i` here is word `i` on the page.
 */
export function tokenize(text: string): WordToken[] {
	const words: WordToken[] = [];
	for (const match of text.matchAll(/\S+/g)) {
		words.push({ text: match[0], start: match.index, end: match.index + match[0].length });
	}
	return words;
}

/** Lowercased letters and digits only, for matching spoken words to written ones. */
export function normalizeWord(word: string): string {
	return word.normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
}

/** Short stable fingerprint of the narrated text, to tell when audio is out of date. */
export async function sourceHash(blocks: readonly SourceBlock[], script: Readonly<Record<string, string | null>> = {}) {
	const payload = JSON.stringify(blocks.map((block) => [block.key, block.kind, block.text, script[block.key] ?? 0]));
	const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(payload));
	return Array.from(new Uint8Array(digest).slice(0, 10), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
