/**
 * emdash-plugin-article-audio
 *
 * Register in astro.config.mjs:
 *
 *   import { articleAudio } from "emdash-plugin-article-audio";
 *   emdash({ plugins: [articleAudio()] })
 */
import type { PluginDescriptor } from "emdash";
import { PLUGIN_ID, PLUGIN_VERSION } from "./plugin.ts";

export function articleAudio(): PluginDescriptor {
	return {
		id: PLUGIN_ID,
		version: PLUGIN_VERSION,
		format: "native",
		entrypoint: "emdash-plugin-article-audio",
		adminEntry: "emdash-plugin-article-audio/admin",
	};
}

export { createPlugin, PLUGIN_ID, PLUGIN_VERSION } from "./plugin.ts";
export type { Narration, NarrationBlock, NarrationTiming } from "./client/index.ts";
export type { Provider, ProviderConfig, Voice, VoiceOptions } from "./providers/index.ts";
