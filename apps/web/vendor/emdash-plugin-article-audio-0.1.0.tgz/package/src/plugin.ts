/**
 * Runtime definition: storage, settings, routes and hooks.
 *
 * Private routes (editors, from the Audio panel):
 *   GET  status   ?collection&id   narration + job progress + whether the text changed
 *   GET  script   ?collection&id   blocks, saved script, voice choice
 *   POST script                    save script overrides and voice choice
 *   POST generate                  start a job (or retry a failed one)
 *   POST step                      run the next chunk / finalize
 *   POST cancel                    drop an unfinished job
 *   POST remove                    delete the narration and its audio
 *   GET  voices   ?provider        voices and models of an engine
 *
 * Public route (sites and apps):
 *   GET  narration ?collection&id  the Narration of a published entry
 */
import { definePlugin, PluginRouteError, type PluginContext, type RouteContext } from "emdash";
import { SUGGESTED_TAGS } from "./core/tags.ts";
import { getProvider, PROVIDER_HOSTS, PROVIDERS } from "./providers/index.ts";
import {
	assertCollection,
	cancelJob,
	deleteNarration,
	entryKey,
	JobError,
	loadEntry,
	narrationSource,
	resumeJob,
	runStep,
	startJob,
	stores,
	summarize,
	toNarration,
	voiceOptions,
	type ScriptRecord,
} from "./server/jobs.ts";
import { loadSettings, providerConfig, SETTINGS_SCHEMA, type AudioSettings } from "./server/settings.ts";

export const PLUGIN_ID = "article-audio";
export const PLUGIN_VERSION = "0.1.0";

const WORKER_TASK = "worker";
/** The worker stops starting new chunks after this long, to end within a cron invocation. */
const WORKER_BUDGET_MS = 40_000;

const isRecord = (value: unknown): value is Record<string, unknown> =>
	typeof value === "object" && value !== null && !Array.isArray(value);
const one = (value: unknown) => (Array.isArray(value) ? value[0] : value);

/** Maps plugin errors to route errors with stable codes. */
async function guard<T>(run: () => Promise<T>): Promise<T> {
	try {
		return await run();
	} catch (error) {
		if (error instanceof JobError) throw new PluginRouteError(error.code, error.message, error.status);
		throw error;
	}
}

function target(input: unknown, settings: AudioSettings) {
	const record = isRecord(input) ? input : {};
	const collection = assertCollection(settings, one(record.collection));
	const id = one(record.id);
	if (typeof id !== "string" || !id) throw new JobError("INVALID_INPUT", "Missing entry id");
	return { collection, id, key: entryKey(collection, id) };
}

async function statusOf(ctx: PluginContext, settings: AudioSettings, collection: string, id: string) {
	const { jobs, narrations, scripts } = stores(ctx);
	const key = entryKey(collection, id);
	const [entry, job, narration, script] = await Promise.all([
		loadEntry(ctx, collection, id),
		jobs.get(key),
		narrations.get(key),
		scripts.get(key),
	]);
	const source = await narrationSource(entry.data, settings, script);
	const { provider, options } = voiceOptions(settings, script);
	const config = providerConfig(ctx, settings);
	return {
		narration: narration ? toNarration(narration, (path) => path) : null,
		stale: Boolean(narration && narration.sourceHash !== source.hash),
		job: summarize(job),
		source: {
			blocks: source.items.length,
			chars: source.chars,
			hash: source.hash,
			published: entry.status === "published",
		},
		voice: {
			provider: provider.id,
			providerLabel: provider.label,
			configured: provider.isConfigured(config),
			voiceId: options.voiceId,
			voiceName: options.voiceName,
			model: options.model,
			timing: provider.hasTiming(options) ? "word" : "estimated",
		},
	};
}

async function scriptOf(ctx: PluginContext, settings: AudioSettings, collection: string, id: string) {
	const { scripts } = stores(ctx);
	const entry = await loadEntry(ctx, collection, id);
	const script = await scripts.get(entryKey(collection, id));
	const source = await narrationSource(entry.data, settings, script);
	const { provider, options } = voiceOptions(settings, script);
	const config = providerConfig(ctx, settings);
	const overrides = script?.overrides ?? {};
	return {
		blocks: source.blocks.map((block) => ({
			...block,
			script: typeof overrides[block.key] === "string" ? overrides[block.key] : null,
			skipped: overrides[block.key] === null,
		})),
		voice: { provider: provider.id, ...options },
		providers: PROVIDERS.map((p) => ({ id: p.id, label: p.label, configured: p.isConfigured(config), models: p.models })),
		tags: SUGGESTED_TAGS,
		chars: source.chars,
	};
}

function readOverrides(value: unknown): Record<string, string | null> {
	if (!isRecord(value)) return {};
	const overrides: Record<string, string | null> = {};
	for (const [key, text] of Object.entries(value)) {
		if (key.length > 100) continue;
		if (text === null) overrides[key] = null;
		else if (typeof text === "string" && text.length <= 20_000) overrides[key] = text;
	}
	return overrides;
}

/** Works through running jobs until the budget is spent. */
async function work(ctx: PluginContext) {
	const settings = await loadSettings(ctx);
	const { jobs } = stores(ctx);
	const started = Date.now();
	const running = await jobs.query({ where: { state: "running" }, orderBy: { updatedAt: "asc" }, limit: 5 });
	for (const { id } of running.items) {
		while (Date.now() - started < WORKER_BUDGET_MS) {
			const { job } = await runStep(ctx, settings, id);
			if (!job || job.state !== "running" || (job.leaseUntil && Date.parse(job.leaseUntil) > Date.now())) break;
		}
		if (Date.now() - started >= WORKER_BUDGET_MS) break;
	}
}

export function createPlugin() {
	return definePlugin({
		id: PLUGIN_ID,
		version: PLUGIN_VERSION,
		capabilities: ["content:read", "media:write", "media:bytes:read", "network:request"],
		allowedHosts: [...PROVIDER_HOSTS],
		storage: {
			narrations: { indexes: ["collection", "updatedAt"] },
			jobs: { indexes: ["state", "updatedAt"] },
			scripts: { indexes: ["updatedAt"] },
		},
		admin: {
			entry: "emdash-plugin-article-audio/admin",
			settingsSchema: SETTINGS_SCHEMA as never,
		},
		routes: {
			status: {
				permission: "content:edit_any",
				methods: ["GET"],
				request: { body: "none" },
				handler: (ctx: RouteContext) =>
					guard(async () => {
						const settings = await loadSettings(ctx);
						const { collection, id } = target(ctx.input, settings);
						return statusOf(ctx, settings, collection, id);
					}),
			},
			script: {
				permission: "content:edit_any",
				methods: ["GET"],
				request: { body: "none" },
				handler: (ctx: RouteContext) =>
					guard(async () => {
						const settings = await loadSettings(ctx);
						const { collection, id } = target(ctx.input, settings);
						return scriptOf(ctx, settings, collection, id);
					}),
			},
			"save-script": {
				permission: "content:edit_any",
				methods: ["POST"],
				request: { body: "json", maxBytes: 512 * 1024 },
				handler: (ctx: RouteContext) =>
					guard(async () => {
						const settings = await loadSettings(ctx);
						const { collection, id, key } = target(ctx.input, settings);
						const body = isRecord(ctx.input) ? ctx.input : {};
						const { scripts } = stores(ctx);
						const previous = await scripts.get(key);
						const providerChanged = typeof body.provider === "string" && getProvider(body.provider).id !== previous?.provider;
						const record: ScriptRecord = {
							overrides: "overrides" in body ? readOverrides(body.overrides) : (previous?.overrides ?? {}),
							provider: typeof body.provider === "string" ? getProvider(body.provider).id : previous?.provider,
							// A voice belongs to its engine: switching engines resets it unless a new one is sent.
							voiceId: typeof body.voiceId === "string" ? body.voiceId.slice(0, 200) : providerChanged ? undefined : previous?.voiceId,
							voiceName:
								typeof body.voiceName === "string" ? body.voiceName.slice(0, 200) : providerChanged ? null : (previous?.voiceName ?? null),
							model: typeof body.model === "string" ? body.model.slice(0, 100) : providerChanged ? null : (previous?.model ?? null),
							speed: typeof body.speed === "number" && body.speed >= 0.5 && body.speed <= 2 ? body.speed : previous?.speed,
							updatedAt: new Date().toISOString(),
						};
						await scripts.put(key, record);
						return scriptOf(ctx, settings, collection, id);
					}),
			},
			generate: {
				permission: "content:edit_any",
				methods: ["POST"],
				request: { body: "json", maxBytes: 4 * 1024 },
				handler: (ctx: RouteContext) =>
					guard(async () => {
						const settings = await loadSettings(ctx);
						const { collection, id, key } = target(ctx.input, settings);
						const resume = isRecord(ctx.input) && ctx.input.resume === true;
						const resumed = resume ? await resumeJob(ctx, key) : null;
						if (!resumed) await startJob(ctx, settings, collection, id, ctx.user?.id ?? null);
						return statusOf(ctx, settings, collection, id);
					}),
			},
			step: {
				permission: "content:edit_any",
				methods: ["POST"],
				request: { body: "json", maxBytes: 4 * 1024 },
				handler: (ctx: RouteContext) =>
					guard(async () => {
						const settings = await loadSettings(ctx);
						const { collection, id, key } = target(ctx.input, settings);
						await runStep(ctx, settings, key);
						return statusOf(ctx, settings, collection, id);
					}),
			},
			cancel: {
				permission: "content:edit_any",
				methods: ["POST"],
				request: { body: "json", maxBytes: 4 * 1024 },
				handler: (ctx: RouteContext) =>
					guard(async () => {
						const settings = await loadSettings(ctx);
						const { collection, id, key } = target(ctx.input, settings);
						await cancelJob(ctx, key);
						return statusOf(ctx, settings, collection, id);
					}),
			},
			remove: {
				permission: "content:edit_any",
				methods: ["POST"],
				request: { body: "json", maxBytes: 4 * 1024 },
				handler: (ctx: RouteContext) =>
					guard(async () => {
						const settings = await loadSettings(ctx);
						const { collection, id, key } = target(ctx.input, settings);
						await deleteNarration(ctx, key);
						return statusOf(ctx, settings, collection, id);
					}),
			},
			voices: {
				permission: "content:edit_any",
				methods: ["GET"],
				request: { body: "none" },
				handler: (ctx: RouteContext) =>
					guard(async () => {
						const settings = await loadSettings(ctx);
						const query = isRecord(ctx.input) ? ctx.input : {};
						const provider = query.provider ? getProvider(one(query.provider)) : settings.provider;
						const config = providerConfig(ctx, settings);
						if (!provider.isConfigured(config)) return { provider: provider.id, configured: false, voices: [], models: provider.models };
						const cacheKey = `voices:${provider.id}`;
						const cached = await ctx.kv.get<{ at: number; voices: unknown[] }>(cacheKey);
						const fresh = cached && Date.now() - cached.at < 3_600_000 && one(query.refresh) !== "1";
						const voices = fresh ? cached.voices : await provider.listVoices(config);
						if (!fresh) await ctx.kv.set(cacheKey, { at: Date.now(), voices });
						return { provider: provider.id, configured: true, voices, models: provider.models };
					}),
			},
			narration: {
				public: true,
				methods: ["GET"],
				request: { body: "none" },
				cacheControl: "public, max-age=60, stale-while-revalidate=600",
				handler: async (ctx: RouteContext) => {
					const query = isRecord(ctx.input) ? ctx.input : {};
					const collection = one(query.collection) ?? "posts";
					const id = one(query.id);
					if (typeof collection !== "string" || typeof id !== "string" || !id || id.length > 100) {
						throw PluginRouteError.badRequest("Pass collection and id");
					}
					const entry = await ctx.content?.get(collection, id);
					const record = entry?.status === "published" ? await stores(ctx).narrations.get(entryKey(collection, id)) : null;
					if (!record) throw PluginRouteError.notFound("No audio for this entry");
					return toNarration(record, (path) => ctx.url(path));
				},
			},
		},
		hooks: {
			// The worker finishes jobs nobody is watching. Scheduling is idempotent.
			"plugin:install": async (_event, ctx) => {
				await ctx.cron?.schedule(WORKER_TASK, { schedule: "* * * * *" });
			},
			"plugin:activate": async (_event, ctx) => {
				await ctx.cron?.schedule(WORKER_TASK, { schedule: "* * * * *" });
			},
			cron: {
				timeout: 55_000,
				handler: async (event, ctx) => {
					if (event.name === WORKER_TASK) await work(ctx);
				},
			},
			"content:afterPublish": {
				timeout: 10_000,
				handler: async (event, ctx) => {
					const settings = await loadSettings(ctx);
					if (!settings.autoGenerate || !settings.collections.includes(event.collection)) return;
					const id = typeof event.content.id === "string" ? event.content.id : null;
					if (!id) return;
					const { jobs, narrations, scripts } = stores(ctx);
					const key = entryKey(event.collection, id);
					if (await jobs.exists(key)) return;
					const [narration, script] = await Promise.all([narrations.get(key), scripts.get(key)]);
					const data = isRecord(event.content.data) ? event.content.data : {};
					const source = await narrationSource(data, settings, script);
					if (narration?.sourceHash === source.hash || source.items.length === 0) return;
					try {
						await startJob(ctx, settings, event.collection, id, null);
						ctx.log.info("Queued audio for published entry", { key });
					} catch (error) {
						ctx.log.warn("Could not queue audio", { key, error: error instanceof Error ? error.message : String(error) });
					}
				},
			},
		},
	});
}

export default createPlugin;
