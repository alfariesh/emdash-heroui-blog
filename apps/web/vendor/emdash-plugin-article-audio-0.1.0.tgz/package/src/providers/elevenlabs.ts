/**
 * ElevenLabs: character timestamps and expression tags.
 *
 * - `POST /v1/text-to-speech/{voice}/with-timestamps` returns base64 MP3
 *   plus per-character start/end times of the input text.
 * - Eleven v4 and v3 read `[tags]` as delivery cues; they ignore SSML, so a
 *   pause tag is passed through as written. Multilingual v2 and Flash read
 *   `<break time="1s" />` for pauses and would speak other tags aloud, so
 *   those are dropped.
 * - Multilingual v2 and Flash join chunks seamlessly with
 *   `previous_request_ids` (ids are valid for two hours). v3 does not
 *   support stitching; v4 is not documented either way, so it is not sent.
 *
 * Docs: https://elevenlabs.io/docs/api-reference/text-to-speech/convert-with-timestamps
 */
import { base64ToBytes } from "../core/base64.ts";
import type { ChunkPlan } from "../core/chunk.ts";
import { mapAlignment, renderPlainText, wordsFromCharTimes } from "../core/render.ts";
import { pauseSeconds } from "../core/tags.ts";
import { num, ProviderError, responseError, str, type Provider, type ProviderConfig, type Voice, type VoiceOptions } from "./types.ts";

const API = "https://api.elevenlabs.io";

export const ELEVENLABS_MODELS = [
	{ id: "eleven_v4", label: "Eleven v4 (most expressive, tags)", tags: true, maxChars: 10_000 },
	{ id: "eleven_v3", label: "Eleven v3 (expressive, tags)", tags: true, maxChars: 5_000 },
	{ id: "eleven_multilingual_v2", label: "Multilingual v2 (stable long-form)", tags: false, maxChars: 10_000 },
	{ id: "eleven_flash_v2_5", label: "Flash v2.5 (fast, half price)", tags: false, maxChars: 40_000 },
] as const;

export const ELEVENLABS_FORMATS = ["mp3_44100_64", "mp3_44100_96", "mp3_44100_128", "mp3_44100_192"] as const;

const STITCHING_MODELS = new Set(["eleven_multilingual_v2", "eleven_flash_v2_5", "eleven_flash_v2", "eleven_turbo_v2_5"]);
/** multilingual_v2 rejects language_code. */
const NO_LANGUAGE_MODELS = new Set(["eleven_multilingual_v2"]);

/** Characters per request so the base64 response stays well under the 8 MiB fetch cap. */
function charsForFormat(format: string): number {
	const kbps = Number(/_(\d+)$/.exec(format)?.[1] ?? 128);
	// ~12 characters of speech per second; base64 adds a third; keep ~5 MiB of headroom.
	return Math.floor((5 * 1024 * 1024 * 3) / 4 / ((kbps * 1000) / 8) * 12);
}

function modelInfo(model: string | null) {
	return ELEVENLABS_MODELS.find((m) => m.id === model) ?? ELEVENLABS_MODELS[2];
}

function outputFormat(config: ProviderConfig): string {
	const format = str(config.settings.elevenlabsOutputFormat);
	return format && (ELEVENLABS_FORMATS as readonly string[]).includes(format) ? format : "mp3_44100_128";
}

function apiKey(config: ProviderConfig): string {
	const key = str(config.settings.elevenlabsApiKey);
	if (!key) throw new ProviderError("ElevenLabs: add an API key in the plugin settings.", 400);
	return key;
}

interface WithTimestampsResponse {
	audio_base64?: string;
	alignment?: {
		characters?: string[];
		character_start_times_seconds?: number[];
		character_end_times_seconds?: number[];
	} | null;
}

export function renderForModel(plan: ChunkPlan, model: string) {
	const tags = modelInfo(model).tags;
	return renderPlainText(plan, (tag) => {
		if (tags) return tag.raw;
		const pause = pauseSeconds(tag.name);
		return pause === null ? null : ` <break time="${pause}s" /> `;
	});
}

export const elevenlabs: Provider = {
	id: "elevenlabs",
	label: "ElevenLabs",
	hosts: ["api.elevenlabs.io"],
	models: ELEVENLABS_MODELS.map(({ id, label, tags }) => ({ id, label, tags })),

	isConfigured: (config) => Boolean(str(config.settings.elevenlabsApiKey)),

	defaults: (settings) => ({
		voiceId: str(settings.elevenlabsVoiceId) ?? "",
		model: modelInfo(str(settings.elevenlabsModel)).id,
		language: str(settings.language),
		speed: num(settings.speed, 1),
		style: null,
	}),

	limits(options, config) {
		const max = Math.min(modelInfo(options.model).maxChars, charsForFormat(outputFormat(config)));
		return { maxChars: max, targetChars: Math.min(2_500, Math.floor(max * 0.85)) };
	},

	hasTiming: () => true,

	async synthesize(plan, options, context, config) {
		if (!options.voiceId) throw new ProviderError("ElevenLabs: choose a voice first.", 400);
		const model = modelInfo(options.model);
		const format = outputFormat(config);
		const rendered = renderForModel(plan, model.id);
		if (rendered.chars.length > model.maxChars) {
			throw new ProviderError(`ElevenLabs: a chunk of ${rendered.chars.length} characters is over the ${model.id} limit.`, 400);
		}

		const body: Record<string, unknown> = {
			text: rendered.text,
			model_id: model.id,
			apply_text_normalization: "auto",
		};
		const speed = Math.min(Math.max(options.speed, 0.7), 1.2);
		if (speed !== 1) body.voice_settings = { speed };
		if (options.language && !NO_LANGUAGE_MODELS.has(model.id)) body.language_code = options.language.slice(0, 2).toLowerCase();
		if (STITCHING_MODELS.has(model.id) && context.previousRequestIds.length) {
			body.previous_request_ids = context.previousRequestIds.slice(-3);
		}

		const url = `${API}/v1/text-to-speech/${encodeURIComponent(options.voiceId)}/with-timestamps?output_format=${format}`;
		const response = await config.fetch(url, {
			method: "POST",
			headers: { "xi-api-key": apiKey(config), "Content-Type": "application/json", Accept: "application/json" },
			body: JSON.stringify(body),
		});
		if (!response.ok) throw await responseError("ElevenLabs", response);

		const data = (await response.json()) as WithTimestampsResponse;
		if (!data.audio_base64) throw new ProviderError("ElevenLabs: the response had no audio.");
		const audio = base64ToBytes(data.audio_base64);

		const alignment = data.alignment;
		let timing = null;
		if (alignment?.characters?.length && alignment.character_start_times_seconds && alignment.character_end_times_seconds) {
			const { start, end } = mapAlignment(rendered, alignment.characters, alignment.character_start_times_seconds, alignment.character_end_times_seconds);
			timing = wordsFromCharTimes(rendered, start, end, plan.segments.length);
		}
		return { audio, timing, requestId: response.headers.get("request-id") ?? undefined };
	},

	async listVoices(config) {
		const voices: Voice[] = [];
		let token: string | null = null;
		for (let page = 0; page < 5; page++) {
			const query = new URLSearchParams({ page_size: "100", include_total_count: "false" });
			if (token) query.set("next_page_token", token);
			const response = await config.fetch(`${API}/v2/voices?${query}`, { headers: { "xi-api-key": apiKey(config) } });
			if (!response.ok) throw await responseError("ElevenLabs", response);
			const data = (await response.json()) as {
				voices?: Array<{ voice_id: string; name: string; category?: string; preview_url?: string; labels?: Record<string, string> }>;
				has_more?: boolean;
				next_page_token?: string | null;
			};
			for (const voice of data.voices ?? []) {
				const labels = voice.labels ?? {};
				const description = [labels.accent, labels.gender, labels.age, labels.language ?? labels.use_case].filter(Boolean).join(" · ");
				voices.push({
					id: voice.voice_id,
					name: voice.name,
					description: description || voice.category,
					language: labels.language,
					previewUrl: voice.preview_url,
				});
			}
			if (!data.has_more || !data.next_page_token) break;
			token = data.next_page_token;
		}
		return voices;
	},
};
