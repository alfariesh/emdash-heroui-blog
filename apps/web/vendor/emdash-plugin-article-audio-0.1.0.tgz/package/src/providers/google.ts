/**
 * Google Cloud Text-to-Speech.
 *
 * - Word timing: `v1beta1/text:synthesize` with `enableTimePointing:
 *   ["SSML_MARK"]` returns the time of every `<mark>`. A mark is placed
 *   before each word, so each word starts at its mark and ends at the next.
 *   Standard, WaveNet and Neural2 voices honour marks; Chirp 3 HD, Studio
 *   and Gemini voices do not, so their timing is estimated.
 * - Pauses become `<break>`; other tags are dropped (Cloud TTS has no
 *   bracket cues outside Gemini).
 * - Requests are capped at 5,000 bytes of SSML, and marks are long, so
 *   chunks are small. MP3 output is fixed at 32 kbps by Google.
 * - Auth: a service-account JSON key (signed into an OAuth token with
 *   WebCrypto) or an API key restricted to the Text-to-Speech API.
 *
 * Docs: https://cloud.google.com/text-to-speech/docs/reference/rest/v1beta1/text/synthesize
 */
import { base64ToBytes, bytesToBase64Url } from "../core/base64.ts";
import type { ChunkPlan } from "../core/chunk.ts";
import type { SpokenWord } from "../core/render.ts";
import { pauseSeconds } from "../core/tags.ts";
import { num, ProviderError, responseError, str, type Provider, type ProviderConfig, type Voice, type VoiceOptions } from "./types.ts";

const API = "https://texttospeech.googleapis.com";
const TOKEN_URL = "https://oauth2.googleapis.com/token";
const MAX_SSML_BYTES = 5_000;

/** Voice families that report `<mark>` timepoints. */
export function supportsMarks(voice: string): boolean {
	return !/chirp|journey|studio|gemini|polyglot|casual/i.test(voice) && /standard|wavenet|neural2|news/i.test(voice);
}

/** `en-US-Neural2-F` → `en-US`. */
export function voiceLanguage(voice: string): string | null {
	const match = /^([a-z]{2,3}-[A-Z]{2})/.exec(voice);
	return match ? match[1] : null;
}

const utf8 = new TextEncoder();
const escapeXml = (text: string) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export interface SsmlWord {
	segment: number;
	text: string;
	mark: string;
}

/** SSML for one chunk; with marks, also the word each mark stands before. */
export function buildSsml(plan: ChunkPlan, marks: boolean): { ssml: string; words: SsmlWord[] } {
	const words: SsmlWord[] = [];
	const paragraphs = plan.segments.map((segment, s) => {
		let body = "";
		for (const piece of segment.pieces) {
			if (piece.kind === "tag") {
				const pause = pauseSeconds(piece.name);
				if (pause !== null) body += `<break time="${Math.round(pause * 1000)}ms"/>`;
				continue;
			}
			if (!marks) {
				body += escapeXml(piece.text);
				continue;
			}
			for (const part of piece.text.split(/(\s+)/)) {
				if (!part) continue;
				if (/^\s+$/.test(part)) {
					body += " ";
					continue;
				}
				const mark = `${s}.${words.length}`;
				words.push({ segment: s, text: part, mark });
				body += `<mark name="${mark}"/>${escapeXml(part)}`;
			}
		}
		const pause = segment.kind === "title" || segment.kind === "heading" ? `<break time="450ms"/>` : "";
		return `<p>${body.trim()}${pause}</p>`;
	});
	return { ssml: `<speak>${paragraphs.join("")}</speak>`, words };
}

interface ServiceAccount {
	client_email: string;
	private_key: string;
	token_uri?: string;
}

function readServiceAccount(config: ProviderConfig): ServiceAccount | null {
	const raw = str(config.settings.googleServiceAccount);
	if (!raw) return null;
	try {
		const parsed = JSON.parse(raw) as Partial<ServiceAccount>;
		if (typeof parsed.client_email === "string" && typeof parsed.private_key === "string") return parsed as ServiceAccount;
	} catch {
		// fall through
	}
	throw new ProviderError("Google: the service account key is not valid JSON from Google Cloud.", 400);
}

function pemToDer(pem: string): ArrayBuffer {
	const base64 = pem.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
	const binary = atob(base64);
	const bytes = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
	return bytes.buffer;
}

/** Exchanges a signed service-account JWT for an access token, cached until shortly before expiry. */
async function accessToken(account: ServiceAccount, config: ProviderConfig): Promise<string> {
	const cacheKey = `google-token:${account.client_email}`;
	const cached = await config.cache?.get<{ token: string; expiresAt: number }>(cacheKey);
	if (cached && cached.expiresAt > Date.now() + 60_000) return cached.token;

	const now = Math.floor(Date.now() / 1000);
	const encode = (value: unknown) => bytesToBase64Url(utf8.encode(JSON.stringify(value)));
	const unsigned = `${encode({ alg: "RS256", typ: "JWT" })}.${encode({
		iss: account.client_email,
		scope: "https://www.googleapis.com/auth/cloud-platform",
		aud: TOKEN_URL,
		iat: now,
		exp: now + 3600,
	})}`;
	let key: CryptoKey;
	try {
		key = await crypto.subtle.importKey("pkcs8", pemToDer(account.private_key), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
	} catch {
		throw new ProviderError("Google: the service account private key could not be read.", 400);
	}
	const signature = new Uint8Array(await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, utf8.encode(unsigned)));
	const response = await config.fetch(TOKEN_URL, {
		method: "POST",
		headers: { "Content-Type": "application/x-www-form-urlencoded" },
		body: new URLSearchParams({
			grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
			assertion: `${unsigned}.${bytesToBase64Url(signature)}`,
		}),
	});
	if (!response.ok) throw await responseError("Google sign-in", response);
	const data = (await response.json()) as { access_token?: string; expires_in?: number };
	if (!data.access_token) throw new ProviderError("Google: no access token was returned.");
	await config.cache?.set(cacheKey, { token: data.access_token, expiresAt: Date.now() + (data.expires_in ?? 3600) * 1000 });
	return data.access_token;
}

async function authHeaders(config: ProviderConfig): Promise<Record<string, string>> {
	const account = readServiceAccount(config);
	if (account) return { Authorization: `Bearer ${await accessToken(account, config)}` };
	const key = str(config.settings.googleApiKey);
	if (key) return { "x-goog-api-key": key };
	throw new ProviderError("Google: add a service account key or an API key in the plugin settings.", 400);
}

/** Bytes of SSML a script turns into: escaped text plus, per word, a mark of ~20 bytes. */
function ssmlBytes(script: string, marks: boolean): number {
	const bytes = utf8.encode(script).length;
	const words = script.split(/\s+/).filter(Boolean).length;
	return Math.ceil(bytes * 1.08 + (marks ? words * 22 : 0));
}

export const google: Provider = {
	id: "google",
	label: "Google Cloud",
	hosts: ["texttospeech.googleapis.com", "oauth2.googleapis.com"],
	models: [],

	isConfigured: (config) => Boolean(str(config.settings.googleServiceAccount) || str(config.settings.googleApiKey)),

	defaults: (settings) => ({
		voiceId: str(settings.googleVoice) ?? "en-US-Neural2-F",
		model: null,
		language: str(settings.language),
		speed: num(settings.speed, 1),
		style: null,
	}),

	limits(options) {
		const marks = supportsMarks(options.voiceId);
		// Per-paragraph <p></p> and the <speak> wrapper take ~40 bytes on top.
		const max = MAX_SSML_BYTES - 400;
		return { maxChars: max, targetChars: max - 300, measure: (script) => ssmlBytes(script, marks) };
	},

	hasTiming: (options) => supportsMarks(options.voiceId),

	async synthesize(plan, options, _context, config) {
		const marks = supportsMarks(options.voiceId);
		const { ssml, words } = buildSsml(plan, marks);
		if (utf8.encode(ssml).length > MAX_SSML_BYTES) {
			throw new ProviderError(`Google: a chunk is ${utf8.encode(ssml).length} bytes of SSML, over the 5,000-byte limit.`, 400);
		}
		const languageCode = voiceLanguage(options.voiceId) ?? options.language ?? "en-US";
		const body: Record<string, unknown> = {
			input: { ssml },
			voice: { languageCode, name: options.voiceId },
			audioConfig: { audioEncoding: "MP3", speakingRate: Math.min(Math.max(options.speed, 0.25), 2) },
		};
		if (marks) body.enableTimePointing = ["SSML_MARK"];

		const response = await config.fetch(`${API}/v1beta1/text:synthesize`, {
			method: "POST",
			headers: { ...(await authHeaders(config)), "Content-Type": "application/json" },
			body: JSON.stringify(body),
		});
		if (!response.ok) throw await responseError("Google", response);
		const data = (await response.json()) as { audioContent?: string; timepoints?: Array<{ markName?: string; timeSeconds?: number }> };
		if (!data.audioContent) throw new ProviderError("Google: the response had no audio.");
		const audio = base64ToBytes(data.audioContent);

		if (!marks || !data.timepoints?.length) return { audio, timing: null };
		const times = new Map(data.timepoints.map((point) => [point.markName ?? "", point.timeSeconds ?? Number.NaN]));
		const timing: SpokenWord[][] = plan.segments.map(() => []);
		words.forEach((word, index) => {
			const start = times.get(word.mark) ?? Number.NaN;
			const next = words[index + 1];
			// A word ends where the next one in its paragraph starts; the last one is filled in later.
			const end = next && next.segment === word.segment ? (times.get(next.mark) ?? Number.NaN) : Number.NaN;
			timing[word.segment].push({ text: word.text, start, end });
		});
		return { audio, timing };
	},

	async listVoices(config) {
		const response = await config.fetch(`${API}/v1/voices`, { headers: await authHeaders(config) });
		if (!response.ok) throw await responseError("Google", response);
		const data = (await response.json()) as { voices?: Array<{ name: string; languageCodes?: string[]; ssmlGender?: string }> };
		return (data.voices ?? [])
			.map(
				(voice): Voice => ({
					id: voice.name,
					name: voice.name,
					language: voice.languageCodes?.[0],
					description: [
						voice.languageCodes?.[0],
						voice.ssmlGender?.toLowerCase(),
						supportsMarks(voice.name) ? "word timing" : "estimated timing",
					]
						.filter(Boolean)
						.join(" · "),
				}),
			)
			.sort((a, b) => a.id.localeCompare(b.id));
	},
};
