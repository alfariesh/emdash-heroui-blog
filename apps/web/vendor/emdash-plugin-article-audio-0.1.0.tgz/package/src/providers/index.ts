import { elevenlabs } from "./elevenlabs.ts";
import { google } from "./google.ts";
import { silent } from "./silent.ts";
import type { Provider } from "./types.ts";

/** Every built-in engine, in the order the settings list them. */
export const PROVIDERS: readonly Provider[] = [elevenlabs, google, silent];

export function getProvider(id: unknown): Provider {
	return PROVIDERS.find((provider) => provider.id === id) ?? elevenlabs;
}

/** Hosts the plugin may call: the union of every provider's hosts. */
export const PROVIDER_HOSTS: readonly string[] = [...new Set(PROVIDERS.flatMap((provider) => provider.hosts))];

export type { Provider, ProviderConfig, SynthesisResult, Voice, VoiceOptions } from "./types.ts";
export { ProviderError } from "./types.ts";
