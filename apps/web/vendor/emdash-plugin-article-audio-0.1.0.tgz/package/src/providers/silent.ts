/**
 * Silent test audio: no API key, no network.
 *
 * Produces silent MP3 as long as the text would take to read at about 165
 * words a minute, with estimated word timing. It exercises the whole
 * pipeline (chunking, storage, joining, the player and its highlighting)
 * for local development and demos without spending credits.
 */
import { tokenize } from "../core/text.ts";
import { silentMp3 } from "../core/mp3.ts";
import type { Provider } from "./types.ts";

const WORDS_PER_SECOND = 165 / 60;
const BREAK_SECONDS = 0.6;

export const silent: Provider = {
	id: "silent",
	label: "Silent test audio (no API key)",
	hosts: [],
	models: [],
	isConfigured: () => true,
	defaults: () => ({ voiceId: "silent", model: null, language: null, speed: 1, style: null }),
	limits: () => ({ maxChars: 3_000, targetChars: 2_000 }),
	hasTiming: () => false,
	async synthesize(plan, options) {
		const words = plan.segments.reduce(
			(sum, segment) => sum + segment.pieces.reduce((n, piece) => n + (piece.kind === "text" ? tokenize(piece.text).length : 0), 0),
			0,
		);
		const seconds = words / (WORDS_PER_SECOND * Math.max(options.speed, 0.25)) + plan.segments.length * BREAK_SECONDS;
		return { audio: silentMp3(seconds * 1000), timing: null };
	},
	listVoices: async () => [{ id: "silent", name: "Silence", description: "Test audio without an API key" }],
};
