/**
 * The contract every speech engine implements.
 *
 * A provider turns one chunk plan into MP3 bytes plus, when the engine can
 * say when each word was spoken, the spoken words per segment. Providers
 * never touch EmDash: they get a fetch function limited to their own hosts
 * and the settings they declared, which keeps them unit-testable and lets
 * the same code run in a sandboxed build later.
 */
import type { ChunkLimits, ChunkPlan } from "../core/chunk.ts";
import type { ChunkTiming } from "../core/render.ts";

export type Fetch = (url: string, init?: RequestInit) => Promise<Response>;

/** What an editor picked for one narration, with settings filled in. */
export interface VoiceOptions {
	voiceId: string;
	model: string | null;
	/** BCP 47 or ISO 639-1 code; providers ignore what they cannot use. */
	language: string | null;
	/** 1 = normal. */
	speed: number;
	/** Free-text delivery direction (used by engines that accept one). */
	style: string | null;
}

export interface ProviderConfig {
	/** Settings values this provider reads, already decrypted. */
	settings: Readonly<Record<string, unknown>>;
	fetch: Fetch;
	/** Plugin KV for tokens and caches, namespaced by the caller. */
	cache?: {
		get<T>(key: string): Promise<T | null>;
		set(key: string, value: unknown): Promise<void>;
	};
}

export interface SynthesisContext {
	/** 0-based chunk index and count, for engines that stitch requests. */
	index: number;
	total: number;
	/** Request ids returned for the previous chunks, newest last, still fresh. */
	previousRequestIds: string[];
}

export interface SynthesisResult {
	/** Constant-bitrate MP3. */
	audio: Uint8Array;
	/** Spoken words per segment, or null when the engine returns no timestamps. */
	timing: ChunkTiming;
	/** Engine request id, for stitching the next chunk. */
	requestId?: string;
}

export interface Voice {
	id: string;
	name: string;
	/** Short description: accent, gender, language. */
	description?: string;
	language?: string;
	previewUrl?: string;
}

export interface ModelOption {
	id: string;
	label: string;
	/** True when the model reads `[tags]` as delivery cues. */
	tags: boolean;
}

export interface ProviderInfo {
	id: string;
	label: string;
	/** Hosts this provider calls; merged into the plugin's allowed hosts. */
	hosts: readonly string[];
	models: readonly ModelOption[];
}

export interface Provider extends ProviderInfo {
	/** True when the credentials it needs are present. */
	isConfigured(config: ProviderConfig): boolean;
	/** Defaults from settings for a new narration. */
	defaults(settings: Readonly<Record<string, unknown>>): VoiceOptions;
	limits(options: VoiceOptions, config: ProviderConfig): ChunkLimits & { measure?: (script: string) => number };
	/** Whether this voice/model returns word timing. */
	hasTiming(options: VoiceOptions): boolean;
	synthesize(plan: ChunkPlan, options: VoiceOptions, context: SynthesisContext, config: ProviderConfig): Promise<SynthesisResult>;
	listVoices(config: ProviderConfig): Promise<Voice[]>;
}

/** An error whose message is safe to show to editors (no secrets, no raw bodies). */
export class ProviderError extends Error {
	readonly status: number;
	readonly retryable: boolean;
	constructor(message: string, status = 502, retryable = false) {
		super(message);
		this.name = "ProviderError";
		this.status = status;
		this.retryable = retryable;
	}
}

/** Turns a failed engine response into a readable error, with the engine's own message when it has one. */
export async function responseError(provider: string, response: Response): Promise<ProviderError> {
	let detail = "";
	try {
		const body = (await response.json()) as Record<string, unknown>;
		const inner = (body.detail ?? body.error ?? body) as Record<string, unknown> | string;
		detail = typeof inner === "string" ? inner : String(inner?.message ?? inner?.status ?? "");
	} catch {
		// Not JSON; the status says enough.
	}
	const retryable = response.status === 429 || response.status >= 500;
	const reason =
		response.status === 401 || response.status === 403
			? "the API key was rejected"
			: response.status === 429
				? "rate limit or quota reached"
				: `HTTP ${response.status}`;
	return new ProviderError(`${provider}: ${reason}${detail ? ` (${detail.slice(0, 200)})` : ""}`, response.status, retryable);
}

export const str = (value: unknown): string | null => (typeof value === "string" && value.trim() ? value.trim() : null);
export const num = (value: unknown, fallback: number): number => (typeof value === "number" && Number.isFinite(value) ? value : fallback);
