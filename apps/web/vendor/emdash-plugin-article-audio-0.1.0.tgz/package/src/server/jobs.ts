/**
 * Narration jobs: a resumable, one-chunk-at-a-time pipeline.
 *
 *   start → step (chunk 1) → step (chunk 2) → … → step (finalize)
 *
 * Each step synthesizes one chunk and stores it as a temporary media item,
 * so a request never runs long, progress can be shown, and a failure costs
 * only the chunk that failed: "Retry" resumes where it stopped. The admin
 * panel drives steps while it is open; the cron worker finishes jobs the
 * editor left (and jobs started by "Generate on publish").
 *
 * Finalize joins the parts into one MP3, maps word timings onto the page
 * text, stores the narration, and removes the parts and any previous audio.
 */
import type { PluginContext, StorageCollection } from "emdash";
import { buildBlocks, chunkTimeline, offsetTimeline, type BlockTimeline } from "../core/align.ts";
import { toArrayBuffer } from "../core/base64.ts";
import { planChunks, type ChunkPlan, type ScriptItem } from "../core/chunk.ts";
import { concatMp3, scanMp3 } from "../core/mp3.ts";
import { stripTags } from "../core/tags.ts";
import { extractBlocks, sourceHash, type SourceBlock } from "../core/text.ts";
import { NARRATION_FORMAT, type Narration, type NarrationTiming } from "../client/index.ts";
import { getProvider, ProviderError, type VoiceOptions } from "../providers/index.ts";
import { providerConfig, type AudioSettings } from "./settings.ts";

/** Per-entry choices saved from the Audio panel. */
export interface ScriptRecord {
	/** Spoken text per block key; `null` skips the block. Missing keys read the page text. */
	overrides: Record<string, string | null>;
	provider?: string;
	voiceId?: string;
	voiceName?: string | null;
	model?: string | null;
	speed?: number;
	updatedAt: string;
}

export interface ChunkState {
	plan: ChunkPlan;
	/** Billable characters (script, tags included). */
	chars: number;
	status: "pending" | "done";
	mediaId?: string;
	durationMs?: number;
	requestId?: string;
	finishedAt?: string;
	timeline?: BlockTimeline[];
}

export interface JobRecord {
	state: "running" | "failed";
	collection: string;
	contentId: string;
	slug: string | null;
	locale: string | null;
	provider: string;
	options: VoiceOptions & { voiceName: string | null };
	timing: NarrationTiming;
	blocks: SourceBlock[];
	sourceHash: string;
	chunks: ChunkState[];
	leaseUntil: string | null;
	error: string | null;
	attempts: number;
	createdAt: string;
	updatedAt: string;
	createdBy: string | null;
}

/** Stored narration: the public contract plus what the plugin needs to manage it. */
export interface NarrationRecord extends Omit<Narration, "audio"> {
	audio: Omit<Narration["audio"], "url"> & { path: string; mediaId: string };
	chars: number;
	updatedAt: string;
}

export interface JobSummary {
	state: "idle" | "running" | "failed";
	done: number;
	total: number;
	chars: number;
	error: string | null;
	busy: boolean;
	updatedAt: string | null;
	finalizing: boolean;
}

/** One chunk per step keeps requests short; a lease stops two tabs synthesizing the same chunk. */
const LEASE_MS = 120_000;
/** ElevenLabs keeps request ids for stitching for two hours. */
const STITCH_WINDOW_MS = 110 * 60_000;
const MAX_PART_BYTES = 16 * 1024 * 1024;

export const entryKey = (collection: string, id: string) => `${collection}:${id}`;

const now = () => new Date().toISOString();

export function stores(ctx: PluginContext) {
	return {
		jobs: ctx.storage.jobs as StorageCollection<JobRecord>,
		narrations: ctx.storage.narrations as StorageCollection<NarrationRecord>,
		scripts: ctx.storage.scripts as StorageCollection<ScriptRecord>,
	};
}

export class JobError extends Error {
	readonly code: string;
	readonly status: number;
	constructor(code: string, message: string, status = 400) {
		super(message);
		this.name = "JobError";
		this.code = code;
		this.status = status;
	}
}

export function assertCollection(settings: AudioSettings, collection: unknown): string {
	if (typeof collection !== "string" || !settings.collections.includes(collection)) {
		throw new JobError("COLLECTION_DISABLED", "Audio is not enabled for this collection. Add it under Plugins → article-audio → Collections.");
	}
	return collection;
}

export async function loadEntry(ctx: PluginContext, collection: string, id: unknown) {
	if (typeof id !== "string" || !id) throw new JobError("INVALID_INPUT", "Missing entry id");
	const entry = await ctx.content?.get(collection, id);
	if (!entry) throw new JobError("NOT_FOUND", "Entry not found", 404);
	return entry;
}

export interface NarrationSource {
	blocks: SourceBlock[];
	items: ScriptItem[];
	hash: string;
	chars: number;
}

/** The blocks of an entry and the script to read for them. */
export async function narrationSource(data: Record<string, unknown>, settings: AudioSettings, script: ScriptRecord | null): Promise<NarrationSource> {
	const blocks = extractBlocks(data, {
		bodyFields: settings.bodyFields,
		includeTitle: settings.includeTitle,
		includeExcerpt: settings.includeExcerpt,
	});
	const overrides = script?.overrides ?? {};
	const items: ScriptItem[] = [];
	blocks.forEach((block, index) => {
		const override = Object.hasOwn(overrides, block.key) ? overrides[block.key] : undefined;
		if (override === null) return;
		const text = typeof override === "string" && stripTags(override) ? override : block.text;
		items.push({ block: index, kind: block.kind, script: text });
	});
	const chars = items.reduce((sum, item) => sum + item.script.length, 0);
	const relevant: Record<string, string | null> = {};
	for (const block of blocks) if (Object.hasOwn(overrides, block.key)) relevant[block.key] = overrides[block.key];
	return { blocks, items, hash: await sourceHash(blocks, relevant), chars };
}

/** Voice options for an entry: saved choices over provider defaults. */
export function voiceOptions(settings: AudioSettings, script: ScriptRecord | null) {
	// An entry keeps the engine and voice an editor picked for it; otherwise the site defaults apply.
	const provider = script?.provider ? getProvider(script.provider) : settings.provider;
	const defaults = provider.defaults(settings.values);
	const options: VoiceOptions & { voiceName: string | null } = {
		...defaults,
		voiceId: script?.voiceId || defaults.voiceId,
		model: script?.model || defaults.model,
		speed: typeof script?.speed === "number" ? script.speed : defaults.speed,
		voiceName: (script?.voiceId && script.voiceName) || null,
	};
	return { provider, options };
}

export function summarize(job: JobRecord | null): JobSummary {
	if (!job) return { state: "idle", done: 0, total: 0, chars: 0, error: null, busy: false, updatedAt: null, finalizing: false };
	const done = job.chunks.filter((chunk) => chunk.status === "done").length;
	return {
		state: job.state,
		done,
		total: job.chunks.length,
		chars: job.chunks.reduce((sum, chunk) => sum + chunk.chars, 0),
		error: job.error,
		busy: Boolean(job.leaseUntil && Date.parse(job.leaseUntil) > Date.now()),
		updatedAt: job.updatedAt,
		finalizing: done === job.chunks.length,
	};
}

async function deleteMedia(ctx: PluginContext, ids: Array<string | undefined>) {
	const media = ctx.media;
	if (!media?.delete) return;
	for (const id of ids) {
		if (!id) continue;
		try {
			await media.delete(id);
		} catch (error) {
			ctx.log.warn("Could not delete audio media", { id, error: error instanceof Error ? error.message : String(error) });
		}
	}
}

/** Starts (or restarts) the job for an entry. Parts of a previous unfinished job are discarded. */
export async function startJob(ctx: PluginContext, settings: AudioSettings, collection: string, id: string, userId: string | null) {
	const { jobs, scripts } = stores(ctx);
	const key = entryKey(collection, id);
	const entry = await loadEntry(ctx, collection, id);
	const script = await scripts.get(key);
	const source = await narrationSource(entry.data, settings, script);
	if (source.items.length === 0) throw new JobError("NOTHING_TO_READ", "This entry has no text to narrate yet.");

	const { provider, options } = voiceOptions(settings, script);
	const config = providerConfig(ctx, settings);
	if (!provider.isConfigured(config)) throw new JobError("NOT_CONFIGURED", `${provider.label} is not set up. Add its credentials in the plugin settings.`);
	if (!options.voiceId) throw new JobError("NO_VOICE", "Choose a voice before generating audio.");

	const limits = provider.limits(options, config);
	const plans = planChunks(source.items, limits);

	const existing = await jobs.getVersioned(key);
	if (existing?.value.leaseUntil && Date.parse(existing.value.leaseUntil) > Date.now()) {
		throw new JobError("BUSY", "Audio for this entry is being generated right now.", 409);
	}
	const job: JobRecord = {
		state: "running",
		collection,
		contentId: id,
		slug: entry.slug,
		locale: entry.locale,
		provider: provider.id,
		options,
		timing: provider.hasTiming(options) ? "word" : "estimated",
		blocks: source.blocks,
		sourceHash: source.hash,
		chunks: plans.map((plan) => ({
			plan,
			chars: plan.segments.reduce(
				(sum, segment) => sum + segment.pieces.reduce((n, piece) => n + (piece.kind === "text" ? piece.text.length : piece.raw.length), 0),
				0,
			),
			status: "pending",
		})),
		leaseUntil: null,
		error: null,
		attempts: 0,
		createdAt: now(),
		updatedAt: now(),
		createdBy: userId,
	};
	const written = await jobs.compareAndSet(key, existing?.revision ?? null, job);
	if (!written.applied) throw new JobError("BUSY", "Another request changed this job. Try again.", 409);
	if (existing) await deleteMedia(ctx, existing.value.chunks.map((chunk) => chunk.mediaId));
	return job;
}

/** Retries a failed job from the chunk that failed. */
export async function resumeJob(ctx: PluginContext, key: string) {
	const { jobs } = stores(ctx);
	const current = await jobs.getVersioned(key);
	if (!current || current.value.state !== "failed") return current?.value ?? null;
	const next: JobRecord = { ...current.value, state: "running", error: null, updatedAt: now() };
	const written = await jobs.compareAndSet(key, current.revision, next);
	return written.applied ? next : current.value;
}

export async function cancelJob(ctx: PluginContext, key: string) {
	const { jobs } = stores(ctx);
	const current = await jobs.get(key);
	if (!current) return;
	await jobs.delete(key);
	await deleteMedia(ctx, current.chunks.map((chunk) => chunk.mediaId));
}

export async function deleteNarration(ctx: PluginContext, key: string) {
	const { narrations } = stores(ctx);
	const record = await narrations.get(key);
	if (!record) return false;
	await narrations.delete(key);
	await deleteMedia(ctx, [record.audio.mediaId]);
	return true;
}

/** Claims the job's lease. Returns the claimed job and its revision, or null when busy or gone. */
async function claim(jobs: StorageCollection<JobRecord>, key: string) {
	const current = await jobs.getVersioned(key);
	if (!current || current.value.state !== "running") return null;
	if (current.value.leaseUntil && Date.parse(current.value.leaseUntil) > Date.now()) return null;
	const leased: JobRecord = { ...current.value, leaseUntil: new Date(Date.now() + LEASE_MS).toISOString() };
	const written = await jobs.compareAndSet(key, current.revision, leased);
	return written.applied ? { job: leased, revision: written.revision } : null;
}

/**
 * Runs one unit of work: the next chunk, or the finalize step when every
 * chunk is done. Returns the job state afterwards (null once finished).
 */
export async function runStep(ctx: PluginContext, settings: AudioSettings, key: string): Promise<{ job: JobRecord | null; narration?: NarrationRecord }> {
	const { jobs } = stores(ctx);
	const claimed = await claim(jobs, key);
	if (!claimed) return { job: await jobs.get(key) };
	let { job, revision } = claimed;

	const index = job.chunks.findIndex((chunk) => chunk.status !== "done");
	if (index === -1) {
		try {
			const narration = await finalize(ctx, job);
			await jobs.delete(key);
			return { job: null, narration };
		} catch (error) {
			return { job: await fail(jobs, key, revision, job, error, ctx) };
		}
	}

	const provider = getProvider(job.provider);
	const config = providerConfig(ctx, settings);
	const chunk = job.chunks[index];
	let uploadedId: string | undefined;
	try {
		const fresh = Date.now() - STITCH_WINDOW_MS;
		const previousRequestIds = job.chunks
			.slice(Math.max(0, index - 3), index)
			.filter((c) => c.requestId && c.finishedAt && Date.parse(c.finishedAt) > fresh)
			.map((c) => c.requestId!);
		const result = await provider.synthesize(chunk.plan, job.options, { index, total: job.chunks.length, previousRequestIds }, config);
		const durationMs = scanMp3(result.audio).durationMs;
		if (durationMs <= 0) throw new ProviderError(`${provider.label}: the audio could not be read as MP3.`);

		const media = ctx.media;
		if (!media?.upload) throw new Error("article-audio: media uploads are not available");
		const name = `${job.slug ?? job.contentId}-part-${index + 1}.mp3`;
		const uploaded = await media.upload(name, "audio/mpeg", toArrayBuffer(result.audio));
		uploadedId = uploaded.mediaId;

		const chunks = job.chunks.slice();
		chunks[index] = {
			...chunk,
			status: "done",
			mediaId: uploaded.mediaId,
			durationMs,
			requestId: result.requestId,
			finishedAt: now(),
			timeline: chunkTimeline(chunk.plan, result.timing, durationMs),
		};
		const next: JobRecord = { ...job, chunks, attempts: 0, leaseUntil: null, updatedAt: now() };
		const written = await jobs.compareAndSet(key, revision, next);
		if (!written.applied) {
			// Cancelled or restarted meanwhile: the part belongs to nothing.
			await deleteMedia(ctx, [uploadedId]);
			return { job: await jobs.get(key) };
		}
		return { job: next };
	} catch (error) {
		await deleteMedia(ctx, [uploadedId]);
		return { job: await fail(jobs, key, revision, job, error, ctx) };
	}
}

async function fail(jobs: StorageCollection<JobRecord>, key: string, revision: string, job: JobRecord, error: unknown, ctx: PluginContext) {
	const message = error instanceof ProviderError || error instanceof JobError ? error.message : "Audio generation failed. Check the server log.";
	ctx.log.error("Audio generation failed", { key, error: error instanceof Error ? error.message : String(error) });
	const retryable = error instanceof ProviderError && error.retryable && job.attempts < 2;
	const next: JobRecord = {
		...job,
		// Rate limits and server errors get two automatic retries from the worker.
		state: retryable ? "running" : "failed",
		error: message,
		attempts: job.attempts + 1,
		leaseUntil: retryable ? new Date(Date.now() + 20_000).toISOString() : null,
		updatedAt: now(),
	};
	const written = await jobs.compareAndSet(key, revision, next);
	return written.applied ? next : await jobs.get(key);
}

async function finalize(ctx: PluginContext, job: JobRecord): Promise<NarrationRecord> {
	const media = ctx.media;
	if (!media?.readBytes || !media.upload) throw new Error("article-audio: media access is not available");
	const parts: Uint8Array[] = [];
	for (const chunk of job.chunks) {
		const file = await media.readBytes(chunk.mediaId!, { maxBytes: MAX_PART_BYTES });
		parts.push(file.bytes);
	}
	const joined = concatMp3(parts);

	let offset = 0;
	const timelines: BlockTimeline[] = [];
	job.chunks.forEach((chunk, index) => {
		timelines.push(...offsetTimeline(chunk.timeline ?? [], Math.round(offset)));
		offset += joined.partDurationsMs[index];
	});
	const blocks = buildBlocks(job.blocks, timelines);

	const uploaded = await media.upload(`${job.slug ?? job.contentId}.mp3`, "audio/mpeg", toArrayBuffer(joined.bytes));
	const provider = getProvider(job.provider);
	const record: NarrationRecord = {
		format: NARRATION_FORMAT,
		collection: job.collection,
		contentId: job.contentId,
		locale: job.locale,
		audio: {
			path: uploaded.url,
			mediaId: uploaded.mediaId,
			mimeType: "audio/mpeg",
			durationMs: Math.round(joined.durationMs),
			bytes: joined.bytes.byteLength,
		},
		voice: {
			provider: provider.id,
			providerLabel: provider.label,
			voiceId: job.options.voiceId,
			voiceName: job.options.voiceName,
			model: job.options.model,
		},
		timing: job.timing,
		sourceHash: job.sourceHash,
		generatedAt: now(),
		blocks,
		chars: job.chunks.reduce((sum, chunk) => sum + chunk.chars, 0),
		updatedAt: now(),
	};

	const { narrations } = stores(ctx);
	const key = entryKey(job.collection, job.contentId);
	const previous = await narrations.get(key);
	await narrations.put(key, record);
	await deleteMedia(ctx, [...job.chunks.map((chunk) => chunk.mediaId), previous?.audio.mediaId]);
	ctx.log.info("Audio narration ready", { key, durationMs: record.audio.durationMs, chunks: job.chunks.length, provider: provider.id });
	return record;
}

/** The public shape, with an absolute audio URL. */
export function toNarration(record: NarrationRecord, absolute: (path: string) => string): Narration {
	const { audio, chars: _chars, updatedAt: _updatedAt, ...rest } = record;
	return {
		...rest,
		audio: { url: absolute(audio.path), mimeType: audio.mimeType, durationMs: audio.durationMs, bytes: audio.bytes },
	};
}
