/**
 * Plugin settings: the generated form's schema and a typed reader.
 * Values left unset in the admin fall back to the defaults here.
 */
import type { PluginContext } from "emdash";
import { DEFAULT_BODY_FIELDS } from "../core/text.ts";
import { ELEVENLABS_FORMATS, ELEVENLABS_MODELS } from "../providers/elevenlabs.ts";
import { getProvider, PROVIDERS, type Provider, type ProviderConfig } from "../providers/index.ts";

export const SETTINGS_SCHEMA = {
	provider: {
		type: "select",
		label: "Speech engine",
		description: "Used for new audio. Existing audio keeps the engine it was made with.",
		options: PROVIDERS.map((provider) => ({ value: provider.id, label: provider.label })),
		default: "elevenlabs",
	},
	collections: {
		type: "string",
		label: "Collections",
		description: "Comma-separated collection slugs that get an Audio panel, e.g. posts, pages.",
		default: "posts",
	},
	bodyFields: {
		type: "string",
		label: "Body fields",
		description: "Portable Text field(s) to narrate, first match wins.",
		default: DEFAULT_BODY_FIELDS.join(", "),
	},
	includeTitle: { type: "boolean", label: "Read the title first", default: true },
	includeExcerpt: { type: "boolean", label: "Read the excerpt after the title", default: false },
	autoGenerate: {
		type: "boolean",
		label: "Generate on publish",
		description: "Create or refresh audio in the background when a published text changes. Each run is billed by the engine.",
		default: false,
	},
	language: {
		type: "string",
		label: "Language (optional)",
		description: "ISO code such as en or id. Leave empty to let the engine detect it.",
		default: "",
	},
	speed: { type: "number", label: "Speaking speed", description: "1 is normal.", default: 1, min: 0.7, max: 1.2 },
	elevenlabsApiKey: { type: "secret", label: "ElevenLabs API key", description: "Needs Text to Speech and Voices (read) access." },
	elevenlabsVoiceId: {
		type: "string",
		label: "ElevenLabs default voice ID",
		description: "Editors can pick another voice per article.",
		default: "",
	},
	elevenlabsModel: {
		type: "select",
		label: "ElevenLabs model",
		description: "v4 and v3 read [tags] such as [whispers] or [laughs]; v3 is limited to 5,000 characters per request.",
		options: ELEVENLABS_MODELS.map(({ id, label }) => ({ value: id, label })),
		default: "eleven_multilingual_v2",
	},
	elevenlabsOutputFormat: {
		type: "select",
		label: "ElevenLabs audio quality",
		options: ELEVENLABS_FORMATS.map((format) => ({ value: format, label: format.replace("mp3_44100_", "MP3 44.1 kHz, ") + " kbps" })),
		default: "mp3_44100_128",
	},
	googleServiceAccount: {
		type: "secret",
		label: "Google service account key (JSON)",
		description: "Paste the whole JSON key of a service account with the Cloud Text-to-Speech API enabled.",
	},
	googleApiKey: {
		type: "secret",
		label: "Google API key (alternative)",
		description: "Used when no service account key is set. Restrict it to the Text-to-Speech API.",
	},
	googleVoice: {
		type: "string",
		label: "Google default voice",
		description: "Neural2, WaveNet and Standard voices give word timing, e.g. en-US-Neural2-F or id-ID-Wavenet-A.",
		default: "en-US-Neural2-F",
	},
} as const;

export interface AudioSettings {
	provider: Provider;
	values: Record<string, unknown>;
	collections: string[];
	bodyFields: string[];
	includeTitle: boolean;
	includeExcerpt: boolean;
	autoGenerate: boolean;
}

const list = (value: unknown, fallback: readonly string[]) => {
	const items = typeof value === "string" ? value.split(",").map((item) => item.trim()).filter(Boolean) : [];
	return items.length ? items : [...fallback];
};

export async function loadSettings(ctx: PluginContext): Promise<AudioSettings> {
	const values: Record<string, unknown> = {};
	for (const { key, value } of await ctx.settings.list()) values[key] = value;
	return {
		provider: getProvider(values.provider ?? "elevenlabs"),
		values,
		collections: list(values.collections, ["posts"]),
		bodyFields: list(values.bodyFields, DEFAULT_BODY_FIELDS),
		includeTitle: values.includeTitle !== false,
		includeExcerpt: values.includeExcerpt === true,
		autoGenerate: values.autoGenerate === true,
	};
}

/** What a provider gets: settings, the plugin's allow-listed fetch, and a KV cache. */
export function providerConfig(ctx: PluginContext, settings: AudioSettings): ProviderConfig {
	const http = ctx.http;
	return {
		settings: settings.values,
		fetch: (url, init) => {
			if (!http) throw new Error("article-audio: network access is not available");
			return http.fetch(url, init);
		},
		cache: {
			get: (key) => ctx.kv.get(`cache:${key}`),
			set: (key, value) => ctx.kv.set(`cache:${key}`, value),
		},
	};
}
